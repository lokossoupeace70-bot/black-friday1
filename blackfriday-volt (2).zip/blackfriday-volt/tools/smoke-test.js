/**
 * smoke-test.js — parcours d’achat complet, exécuté contre un vrai serveur.
 * Lance : `npm test`  (le serveur est démarré dans le même processus).
 */
import { server } from '../server/index.js';

// Le serveur est déjà lancé par l’import : on attend la fin du bind pour connaître le port réel.
await new Promise((resolve) => (server.listening ? resolve() : server.once('listening', resolve)));
const BASE = `http://127.0.0.1:${server.address().port}`;
let cookie = '';
const results = [];

const api = async (path, { method = 'GET', body, headers = {} } = {}) => {
  const res = await fetch(BASE + path, {
    method,
    headers: { ...(body ? { 'Content-Type': 'application/json' } : {}), ...(cookie ? { Cookie: cookie } : {}), ...headers },
    body: body ? JSON.stringify(body) : undefined,
  });
  const setCookie = res.headers.getSetCookie?.() ?? [];
  if (setCookie.length) cookie = setCookie.map((c) => c.split(';')[0]).join('; ');
  const text = await res.text();
  let payload;
  try { payload = JSON.parse(text); } catch { payload = text; }
  return { status: res.status, payload, contentType: res.headers.get('content-type') || '' };
};

function check(name, condition, info = '') {
  results.push({ name, ok: !!condition, info });
  console.log(`${condition ? '  ✅' : '  ❌'} ${name}${info ? ` — ${info}` : ''}`);
}

console.log(`\n🔎 Smoke test VOLT sur ${BASE}\n`);

try {
  const health = await api('/api/health');
  check('GET /api/health', health.status === 200 && health.payload.ok === true);

  const event = await api('/api/event');
  check('GET /api/event expose la campagne', event.status === 200 && typeof event.payload.phase === 'string', event.payload.phase);

  const list = await api('/api/products?limit=6&sort=discount');
  check('GET /api/products renvoie une page', list.status === 200 && list.payload.items.length === 6, `${list.payload.total} produits`);
  check('produits triés par remise décroissante',
    list.payload.items.every((p, i, a) => i === 0 || a[i - 1].discount >= p.discount));

  const filtered = await api('/api/products?cat=Gaming&sort=price');
  check('filtre par catégorie', filtered.payload.items.length > 0 && filtered.payload.items.every((p) => p.category === 'Gaming'),
    `${filtered.payload.items.length} produits gaming`);

  const search = await api('/api/products?q=casque');
  check('recherche plein texte', search.payload.items.length > 0, `${search.payload.items.length} résultats`);

  const slug = list.payload.items[0].slug;
  const detail = await api(`/api/products/${slug}`);
  check('GET /api/products/:slug est complet',
    detail.status === 200 && detail.payload.variants.length > 0 && detail.payload.specs.length > 0 && detail.payload.reviews.length > 0,
    `${detail.payload.variants.length} variantes · ${detail.payload.specs.length} specs · ${detail.payload.reviews.length} avis`);
  check('produits associés proposés', detail.payload.relay.length > 0);

  // Contrat d’API : le détail doit exposer les mêmes noms de champs que la liste,
  // sinon le frontend affiche 0 € ou « NaN avis » sans qu’aucune erreur ne remonte.
  const card = list.payload.items[0];
  check('le détail partage le contrat de la liste',
    detail.payload.price === card.price && detail.payload.compare === card.compare && detail.payload.price > 0,
    `${detail.payload.price} / ${detail.payload.compare} centimes`);
  check('compteurs numériques dans le détail',
    Number.isFinite(detail.payload.reviewCount) && Number.isFinite(detail.payload.soldToday) && detail.payload.reviewCount > 0,
    `${detail.payload.reviewCount} avis · ${detail.payload.soldToday} vendus`);
  check('variantes normalisées',
    detail.payload.variants.every((v) => typeof v.group === 'string' && typeof v.delta === 'number'),
    detail.payload.variants.map((v) => `${v.value}${v.delta ? ` +${v.delta}` : ''}`).join(' · '));

  const art = await fetch(`${BASE}${detail.payload.image}`);
  check('visuel SVG généré', art.status === 200 && (art.headers.get('content-type') || '').includes('image/svg+xml'),
    `${(await art.text()).length} octets`);

  // Régression : le générateur de visuels doit tenir sur TOUT le catalogue,
  // et la finition choisie doit produire un rendu distinct.
  const all = await api('/api/products?limit=60');
  const arts = await Promise.all(all.payload.items.map((p) => fetch(BASE + p.image).then((r) => r.status)));
  check('visuels générés pour les 30 produits', arts.every((s) => s === 200), `${arts.filter((s) => s === 200).length}/${arts.length}`);

  const finished = all.payload.items.find((p) => p.slug === slug);
  const plain = await (await fetch(BASE + finished.image)).text();
  const coloured = await (await fetch(`${BASE}${finished.image}?v=${encodeURIComponent('Blanc perle')}`)).text();
  check('le coloris change le visuel produit', plain !== coloured);

  const proof = await api('/api/social-proof');
  check('preuve sociale servie', proof.status === 200 && proof.payload.recent.length > 0 && proof.payload.recent[0].name,
    proof.payload.recent[0]?.city);

  const flash = await api('/api/flash');
  check('offre flash du jour', flash.status === 200 && flash.payload.product?.slug && flash.payload.code === 'FLASH10');

  const empty = await api('/api/cart');
  check('panier initial vide', empty.status === 200 && empty.payload.items.length === 0);

  const added = await api('/api/cart', { method: 'POST', body: { slug, qty: 2, variant: detail.payload.variants[0].value } });
  check('POST /api/cart ajoute une ligne', added.status === 201 && added.payload.items.length === 1 && added.payload.items[0].qty === 2);
  check('frais de port calculés', typeof added.payload.totals.shipping === 'number', `total ${new Intl.NumberFormat('fr-FR').format(added.payload.totals.total)} F CFA`);

  const second = await api('/api/products?limit=3&sort=price&max=30000');
  const secondSlug = second.payload.items[0].slug;
  await api('/api/cart', { method: 'POST', body: { slug: secondSlug, qty: 1 } });
  const twoLines = await api('/api/cart');
  check('plusieurs lignes de panier', twoLines.payload.items.length === 2, `${twoLines.payload.items.length} lignes`);

  const flashCart = await api('/api/cart', { method: 'POST', body: { slug, qty: 1 } });
  check('quantités cumulées sur la même variante', flashCart.payload.items[0].qty === 3);

  const badPromo = await api('/api/promo', { method: 'POST', body: { code: 'NAWAK' } });
  check('code promo invalide rejeté', badPromo.status === 422, badPromo.payload.error);

  const promo = await api('/api/promo', { method: 'POST', body: { code: 'black20' } });
  check('code promo valide appliqué (insensible à la casse)', promo.status === 200 && promo.payload.totals.discount > 0,
    `-${new Intl.NumberFormat('fr-FR').format(promo.payload.totals.discount)} F CFA`);

  const line = twoLines.payload.items[1].id;
  const patched = await api(`/api/cart/${line}`, { method: 'PATCH', body: { qty: 3 } });
  check('PATCH /api/cart/:line modifie la quantité', patched.payload.items.find((i) => i.id === line)?.qty === 3);

  const removed = await api(`/api/cart/${line}`, { method: 'DELETE' });
  check('DELETE /api/cart/:line retire la ligne', removed.payload.items.length === 1);

  const invalidOrder = await api('/api/orders', { method: 'POST', body: { customer: { email: 'pas-un-email', firstName: 'A' } } });
  check('validation du formulaire de commande', invalidOrder.status === 422 && Object.keys(invalidOrder.payload.details || {}).length >= 3,
    Object.keys(invalidOrder.payload.details || {}).join(', '));

  const beforeOrder = await api('/api/cart');
  const orderedQty = beforeOrder.payload.items.reduce((sum, i) => sum + i.qty, 0);

  const order = await api('/api/orders', {
    method: 'POST',
    body: {
      customer: { email: 'client@volt.test', firstName: 'Ada', lastName: 'Lovelace', address: '12 avenue Steinmetz', zip: 'BP 500', city: 'Cotonou', phone: '97000000' },
      paymentMethod: 'carte',
      promoCode: 'BLACK20',
    },
  });
  check('POST /api/orders crée la commande', order.status === 201 && /^VOLT-[A-Z0-9]{6}$/.test(order.payload.number), order.payload.number);
  check('remise appliquée à la commande', order.payload.order.discount_cents > 0);
  check('TVA calculée sur le TTC', order.payload.order.tax_cents > 0, `${new Intl.NumberFormat('fr-FR').format(order.payload.order.tax_cents)} F CFA`);

  const afterOrder = await api('/api/cart');
  check('panier vidé après commande', afterOrder.payload.items.length === 0);

  const lookup = await api(`/api/orders/${order.payload.number}?email=client@volt.test`);
  check('suivi de commande retrouvé', lookup.status === 200 && lookup.payload.items.length >= 1 && lookup.payload.tracking.steps.length === 4);

  const wrongEmail = await api(`/api/orders/${order.payload.number}?email=autre@volt.test`);
  check('suivi protégé par e-mail', wrongEmail.status === 404);

  const stockAfter = await api(`/api/products/${slug}`);
  check('stock décrémenté après commande', stockAfter.payload.stock === detail.payload.stock - orderedQty,
    `${detail.payload.stock} → ${stockAfter.payload.stock} (${orderedQty} vendus)`);

  const newsletter = await api('/api/newsletter', { method: 'POST', body: { email: 'news@volt.test' } });
  check('inscription newsletter', newsletter.status === 201);

  const denied = await api('/api/admin/stats');
  check('admin protégé sans jeton', denied.status === 401);

  const badLogin = await api('/api/admin/login', { method: 'POST', body: { password: 'nope' } });
  check('mauvais mot de passe refusé', badLogin.status === 401);

  const login = await api('/api/admin/login', { method: 'POST', body: { password: process.env.ADMIN_PASSWORD || 'blackfriday2026' } });
  const token = login.payload.token;
  check('connexion admin', login.status === 200 && typeof token === 'string');

  const stats = await api('/api/admin/stats', { headers: { 'x-admin-token': token } });
  check('statistiques admin', stats.status === 200 && stats.payload.orders >= 1 && stats.payload.revenue > 0,
    `${stats.payload.orders} commande(s) · ${new Intl.NumberFormat('fr-FR').format(stats.payload.revenue)} F CFA · panier moyen ${new Intl.NumberFormat('fr-FR').format(stats.payload.aov)} F CFA`);

  const ordersList = await api('/api/admin/orders', { headers: { 'x-admin-token': token } });
  check('liste des commandes admin', ordersList.payload.orders.length >= 1);

  const patchedOrder = await api(`/api/admin/orders/${ordersList.payload.orders[0].id}`, {
    method: 'PATCH', headers: { 'x-admin-token': token }, body: { status: 'expédiée' },
  });
  check('changement de statut de commande', patchedOrder.status === 200);

  const newPromo = await api('/api/admin/promos', {
    method: 'POST', headers: { 'x-admin-token': token }, body: { code: 'TEST20', kind: 'percent', value: 20, label: 'Test' },
  });
  check('création de code promo', newPromo.status === 201);

  const deletePromo = await api('/api/admin/promos/TEST20', { method: 'DELETE', headers: { 'x-admin-token': token } });
  check('suppression de code promo', deletePromo.status === 200);

  const patchProduct = await api(`/api/admin/products/${detail.payload.id}`, {
    method: 'PATCH', headers: { 'x-admin-token': token }, body: { stock: 77 },
  });
  check('mise à jour de stock admin', patchProduct.status === 200);

  const page = await fetch(`${BASE}/`);
  check('page d’accueil servie', page.status === 200 && (page.headers.get('content-type') || '').includes('text/html'));

  const adminPage = await fetch(`${BASE}/admin.html`);
  check('page admin servie', adminPage.status === 200);

  const notApi = await api('/api/inconnu');
  check('404 JSON sur route API inconnue', notApi.status === 404);
} catch (error) {
  console.error('\n💥 Erreur pendant le test :', error);
  process.exitCode = 1;
}

const failed = results.filter((r) => !r.ok);
console.log(`\n${failed.length ? '❌' : '✅'} ${results.length - failed.length}/${results.length} vérifications réussies`);
if (failed.length) {
  console.log('Échecs :', failed.map((f) => f.name).join(', '));
  process.exitCode = 1;
}

server.close();
setTimeout(() => process.exit(process.exitCode || 0), 100);
