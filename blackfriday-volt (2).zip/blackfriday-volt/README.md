# VOLT — boutique Black Friday (tech & gadgets)

Boutique e-commerce complète pour la campagne **Black Friday**, univers high-tech.
Frontend applicatif (SPA) + **API REST** + persistance SQLite. **Zéro dépendance npm** :
rien à installer, `npm start` et c'est en ligne.

```bash
cd blackfriday-volt
npm start                 # http://127.0.0.1:4100
npm test                  # 46 vérifications de bout en bout
npm run reset             # repartir d'un catalogue neuf (supprime data/)
```

- Boutique : http://127.0.0.1:4100
- Console d'exploitation : http://127.0.0.1:4100/admin.html — mot de passe `blackfriday2026`
  (modifiable via la variable d'environnement `ADMIN_PASSWORD`)

---

## 1. Ce que fait la boutique

**Parcours d'achat complet** : accueil → catalogue (filtres, tri, recherche) → fiche produit
(déclinaisons, avis, cross-sell) → panier → code promo → commande → confirmation → suivi de commande.

**Ce qui est conçu pour faire acheter** (et non seulement pour être joli) :

| Levier | Mise en œuvre |
| --- | --- |
| Urgence | Compte à rebours jusqu'à la clôture de la campagne, renouvelé chaque seconde |
| Rareté | Stock réel par produit, barre de consommation, « plus que X en stock » |
| Preuve sociale | Note + nombre d'avis, « N vendus aujourd'hui », toasts de commandes récentes |
| Offre flash | Un produit mis en avant par jour, réduction cumulée, minuteur de rotation |
| Livraison offerte | Jauge de progression « encore X F et c'est offert » dans le panier |
| Réassurance | Garantie 3 ans, retours 30 jours, paiement sécurisé, moyens de paiement affichés |
| Rattrapage | Modale d'intention de sortie offrant un code supplémentaire |
| Ancrage prix | Prix barré, montant économisé en euros, pourcentage de remise |

Prix en **FCFA (XOF)**, TVA béninoise 18 % calculée sur le TTC, livraison offerte au-delà
de 50 000 F, paiement **MTN MoMo · Moov Money · Wave** ou carte bancaire.
Contexte béninois : expédition depuis Cotonou, villes de preuve sociale locales
(Cotonou, Porto-Novo, Abomey-Calavi, Parakou…), adresses au format boîte postale (BP).

## 2. Architecture

```
server/
  core.js      micro-framework HTTP : routeur, sessions signées, statique, parsing
  db.js        schéma SQLite + seed déterministe du catalogue
  art.js       visuels produits générés en SVG (aucun fichier image)
  event.js     configuration de la campagne (dates, seuils, TVA)
  routes.js    API REST complète + back-office
  index.js     point d'entrée
public/
  index.html   coquille de l'application (header, tiroir panier, toasts, modale)
  admin.html   console d'exploitation
  assets/      app.css · app.js · admin.css · admin.js
tools/
  smoke-test.js parcours d'achat complet + API admin
```

Choix techniques :

- **Aucune dépendance** : `node:http` + `node:sqlite` (Node ≥ 22.5). Pas d'installation,
  pas de chaîne de build, pas de surface d'attaque par dépendance transitive.
- **Panier côté serveur** : le client ne fait qu'afficher l'état renvoyé par l'API.
  Le prix affiché est toujours le prix facturé, y compris pour les codes promo.
- **Visuels générés** : chaque produit reçoit une composition SVG déterministe
  (dégradé de marque, halo, silhouette d'appareil, trame technique). La finition
  choisie change réellement le rendu (`/media/<slug>.svg?v=Vert volt`).
- **Cache** : `no-cache` + ETag partout. Une mise à jour est visible au premier
  rechargement, sans hachage de build.

## 3. API REST

| Méthode | Route | Rôle |
| --- | --- | --- |
| GET | `/api/event` | Dates, phase, seuils, catégories |
| GET | `/api/products` | Catalogue : `cat`, `q`, `sort`, `min`, `max`, `deals`, `page`, `limit` |
| GET | `/api/products/:slug` | Fiche complète (déclinaisons, specs, avis, suggestions) |
| GET | `/api/flash` | Offre du jour et son minuteur |
| GET | `/api/social-proof` | Commandes récentes (preuve sociale) |
| GET/POST | `/api/cart` | Lire le panier / ajouter une ligne |
| PATCH/DELETE | `/api/cart/:line` | Modifier la quantité / retirer |
| POST | `/api/promo` | Valider un code sur le panier courant |
| POST | `/api/orders` | Créer la commande (validation serveur, décrément du stock) |
| GET | `/api/orders/:number?email=` | Suivi de commande, protégé par e-mail |
| POST | `/api/newsletter` | Inscription |
| — | `/api/admin/*` | Connexion, statistiques, commandes, stocks, prix, codes promo |

`GET /api` renvoie l'index des routes disponibles.

## 4. Console d'exploitation

- **Vue d'ensemble** : chiffre d'affaires, panier moyen, taux de conversion,
  courbe par jour, répartition par catégorie, meilleures ventes, alertes de stock.
- **Commandes** : recherche, filtre par statut, changement de statut en un clic.
- **Catalogue & stock** : édition du prix et du stock directement dans le tableau.
- **Codes promo** : création, suivi des utilisations, suppression.

## 5. Tests

`npm test` démarre un vrai serveur et déroule le parcours complet : 46 assertions,
dont la décrémentation du stock, la TVA, le calcul du port, la validation du
formulaire, la protection du suivi par e-mail et l'ensemble de l'API admin.

## 6. Ce qui est simulé

Paiement (aucune transaction réelle, aucune donnée bancaire stockée), e-mails de
confirmation et expédition. Le reste — catalogue, stocks, paniers, commandes,
statistiques — est réellement persisté en base.
