/* ============================================================== app.js ====
   Boutique VOLT — application cliente (routeur par hash, sans framework).
   Le panier vit côté serveur : le client ne fait que refléter l’état de l’API.
   ========================================================================= */

/* ------------------------------------------------------------- 1. Outils -- */

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

/* Les montants serveur sont des FCFA entiers (XOF, aucune sous-unité). */
const xof = new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'XOF' });
const money = (cents) => xof.format(cents || 0).replace(/\u202f/g, ' ');
const eur0 = new Intl.NumberFormat('fr-FR', { maximumFractionDigits: 0 });

const escapeHtml = (text) => String(text ?? '').replace(/[&<>"']/g, (c) => (
  { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]
));

const stars = (rating) => {
  const full = Math.round(rating);
  return `<span class="stars" aria-label="${rating} sur 5">${'<svg><use href="#i-star"></use></svg>'.repeat(full)}</span>`;
};

const icon = (name, cls = '') => `<svg class="${cls}"><use href="#i-${name}"></use></svg>`;

const dateFr = (iso) => new Date(iso).toLocaleDateString('fr-FR', { day: '2-digit', month: 'long', year: 'numeric' });
const relTime = (iso) => {
  const mins = Math.max(1, Math.round((Date.now() - new Date(iso).getTime()) / 60000));
  if (mins < 60) return `il y a ${mins} min`;
  const h = Math.round(mins / 60);
  return h < 24 ? `il y a ${h} h` : `il y a ${Math.round(h / 24)} j`;
};

/* ------------------------------------------------------------ 2. L’état -- */

const state = {
  event: null,
  flash: null,
  cart: { items: [], totals: null },
  promo: null,
  wishlist: new Set(JSON.parse(localStorage.getItem('volt_wish') || '[]')),
  socialSeen: new Set(),
};

localStorage.removeItem('volt_wish_pending');
const saveWish = () => localStorage.setItem('volt_wish', JSON.stringify([...state.wishlist]));

/* ---------------------------------------------------------- 3. Transport -- */

async function api(path, { method = 'GET', body, silent = false } = {}) {
  const res = await fetch(path, {
    method,
    headers: body ? { 'Content-Type': 'application/json' } : {},
    body: body ? JSON.stringify(body) : undefined,
  });
  const payload = await res.json().catch(() => ({}));
  if (!res.ok) {
    const error = new Error(payload.error || 'Une erreur est survenue.');
    error.details = payload.details;
    error.status = res.status;
    if (!silent) toast({ title: error.message, text: payload.details ? Object.values(payload.details)[0] : 'Merci de réessayer.', tone: 'hot' });
    throw error;
  }
  return payload;
}

/* ------------------------------------------------------------ 4. Toasts -- */

function toast({ title, text = '', image, iconName = 'check', tone = 'volt', action, ttl = 4200 }) {
  const root = $('#toasts');
  const node = document.createElement('div');
  node.className = 'toast';
  node.innerHTML = `
    ${image ? `<img src="${image}" alt="">` : `<span class="toast__icon" style="${tone === 'hot' ? 'background:var(--hot-soft);color:var(--hot)' : ''}">${icon(tone === 'hot' ? 'bolt' : iconName)}</span>`}
    <div>
      <b>${escapeHtml(title)}</b>
      ${text ? `<span>${escapeHtml(text)}</span>` : ''}
      ${action ? `<br>${action}` : ''}
    </div>`;
  root.append(node);
  setTimeout(() => {
    node.classList.add('is-out');
    node.addEventListener('animationend', () => node.remove(), { once: true });
  }, ttl);
  return node;
}

/* ---------------------------------------------------------- 5. Compte à rebours -- */

function tickCountdown() {
  if (!state.event) return;
  const left = Math.max(0, new Date(state.event.endsAt).getTime() - Date.now());
  const d = Math.floor(left / 864e5);
  const h = Math.floor((left % 864e5) / 36e5);
  const m = Math.floor((left % 36e5) / 6e4);
  const s = Math.floor((left % 6e4) / 1000);
  document.body.dataset.phase = state.event.phase;
  for (const scope of $$('[data-countdown]')) {
    const set = (unit, value) => {
      const el = $(`[data-cd="${unit}"]`, scope);
      if (el) el.textContent = String(value).padStart(2, '0');
    };
    set('d', d); set('h', h); set('m', m); set('s', s);
  }
  const compact = `${d}j ${String(h).padStart(2, '0')}h ${String(m).padStart(2, '0')}m ${String(s).padStart(2, '0')}s`;
  $$('[data-countdown-text]').forEach((el) => { el.textContent = compact; });

  // Minuteries locales (rotation de l’offre flash) : cible ISO propre à l’élément.
  $$('[data-countdown-until]').forEach((el) => {
    const rest = Math.max(0, new Date(el.dataset.countdownUntil).getTime() - Date.now());
    const hh = Math.floor(rest / 36e5);
    const mm = Math.floor((rest % 36e5) / 6e4);
    const ss = Math.floor((rest % 6e4) / 1000);
    el.textContent = `${String(hh).padStart(2, '0')}h ${String(mm).padStart(2, '0')}m ${String(ss).padStart(2, '0')}s`;
  });
}

/* -------------------------------------------------------------- 6. Panier -- */

function cartCount() { return state.cart.items.reduce((n, i) => n + i.qty, 0); }

function renderCartBadge() {
  const n = cartCount();
  const badge = $('#cart-count');
  badge.textContent = n;
  badge.hidden = n === 0;
  const btn = $('#cart-btn');
  btn.classList.remove('is-bump');
  void btn.offsetWidth;
  if (n) btn.classList.add('is-bump');
}

function renderDrawer() {
  const { items, totals } = state.cart;
  $('#drawer-count').textContent = cartCount();

  const ship = $('#drawer-ship');
  if (!items.length) {
    ship.hidden = true;
  } else {
    ship.hidden = false;
    const remaining = totals.shippingRemaining;
    const pct = Math.min(100, Math.round(((totals.freeShippingThreshold - remaining) / totals.freeShippingThreshold) * 100));
    ship.innerHTML = remaining > 0
      ? `Encore <b>${money(remaining)}</b> et la livraison vous est offerte
         <div class="progress"><div class="progress__bar" style="width:${pct}%;background:linear-gradient(90deg,var(--volt),#9dff00)"></div></div>`
      : `<b>Livraison offerte débloquée</b> ✓ — expédition sous 24 h ouvrées.
         <div class="progress"><div class="progress__bar" style="width:100%;background:linear-gradient(90deg,var(--volt),#9dff00)"></div></div>`;
  }

  const body = $('#drawer-body');
  const foot = $('#drawer-foot');

  if (!items.length) {
    body.innerHTML = `<div class="drawer__empty">
        ${icon('cart')}
        <p><b>Votre panier est vide.</b></p>
        <p class="muted">Les remises Black Friday sont actives jusqu’à la fin de l’événement.</p>
        <a class="btn" href="#/boutique" data-act="closeCart">Voir les offres</a>
      </div>`;
    foot.innerHTML = '';
    return;
  }

  body.innerHTML = items.map((line) => `
    <article class="line">
      <img src="${line.image}" alt="${escapeHtml(line.name)}" width="74" height="82" loading="lazy">
      <div>
        <a class="line__name" href="#/produit/${line.slug}" data-act="closeCart">${escapeHtml(line.name)}</a>
        ${line.variant ? `<div class="line__variant">${escapeHtml(line.variant)}</div>` : ''}
        <div class="qty qty--sm">
          <button data-act="qty" data-line="${line.id}" data-delta="-1" aria-label="Diminuer">−</button>
          <b>${line.qty}</b>
          <button data-act="qty" data-line="${line.id}" data-delta="1" aria-label="Augmenter">+</button>
        </div>
      </div>
      <div class="line__right">
        <div class="line__price">${money(line.lineTotal)}</div>
        ${line.compare > line.unit ? `<s class="muted" style="font-size:.74rem">${money(line.compare * line.qty)}</s>` : ''}
        <button class="line__remove" data-act="removeLine" data-line="${line.id}">Retirer</button>
      </div>
    </article>`).join('')
    + `<p class="muted" style="font-size:.78rem;margin:6px 0 0">${icon('shield', '')} Produits garantis 3 ans · retours gratuits 30 jours.</p>`;

  const saved = items.reduce((sum, i) => sum + Math.max(0, i.compare - i.unit) * i.qty, 0);
  foot.innerHTML = `
    <div class="promo-row">
      <input id="promo-input" placeholder="Code promo (essayez BLACK20)" aria-label="Code promo" value="${state.promo ? escapeHtml(state.promo.code) : ''}" ${state.promo ? 'disabled' : ''}>
      <button class="btn btn--ghost btn--sm" data-act="${state.promo ? 'clearPromo' : 'applyPromo'}">${state.promo ? 'Retirer' : 'Appliquer'}</button>
    </div>
    ${state.promo ? `<div class="promo-applied">${icon('check')} <span><b>${escapeHtml(state.promo.code)}</b> — ${escapeHtml(state.promo.label)}</span></div>` : ''}
    <div class="totals">
      <div class="totals__row"><span>Sous-total</span><span class="mono">${money(totals.subtotal)}</span></div>
      ${saved ? `<div class="totals__row totals__row--save"><span>Économies Black Friday</span><span class="mono">−${money(saved)}</span></div>` : ''}
      ${totals.discount ? `<div class="totals__row totals__row--save"><span>Remise ${escapeHtml(state.promo?.code || '')}</span><span class="mono">−${money(totals.discount)}</span></div>` : ''}
      <div class="totals__row"><span>Livraison</span><span class="mono">${totals.shipping ? money(totals.shipping) : 'Offerte'}</span></div>
      <div class="totals__row"><span>dont TVA (20 %)</span><span class="mono">${money(totals.tax)}</span></div>
      <div class="totals__row totals__row--total"><span>Total TTC</span><span class="mono">${money(totals.total)}</span></div>
    </div>
    <a class="btn btn--block btn--lg" href="#/commande" data-act="closeCart">Commander maintenant ${icon('arrow')}</a>
    <div class="trust-note">${icon('lock')} Paiement sécurisé · Mobile Money & carte bancaire</div>`;
}

async function refreshCart() {
  const data = await api('/api/cart', { silent: true });
  state.cart = { items: data.items, totals: data.totals };
  renderCartBadge();
  renderDrawer();
}

function openDrawer() {
  $('#cart-drawer').classList.add('is-open');
  $('#cart-drawer').setAttribute('aria-hidden', 'false');
  $('#scrim').hidden = false;
  document.body.style.overflow = 'hidden';
}
function closeDrawer() {
  $('#cart-drawer').classList.remove('is-open');
  $('#cart-drawer').setAttribute('aria-hidden', 'true');
  $('#scrim').hidden = true;
  document.body.style.overflow = '';
}

async function addToCart(slug, variant, qty = 1, { buyNow = false } = {}) {
  try {
    const data = await api('/api/cart', { method: 'POST', body: { slug, variant, qty } });
    state.cart = { items: data.items, totals: data.totals };
    renderCartBadge();
    renderDrawer();
    const line = data.items.find((i) => i.slug === slug);
    toast({
      title: 'Ajouté au panier ✓',
      text: line ? `${line.name}${line.variant ? ` · ${line.variant}` : ''} × ${line.qty}` : '',
      image: line?.image,
      action: '<a href="#/commande">Passer commande →</a>',
    });
    if (buyNow) { location.hash = '#/commande'; return; }
    openDrawer();
  } catch { /* le toast d’erreur est déjà affiché */ }
}

/* -------------------------------------------------------- 7. Composants -- */

function productCard(p, { wide = false } = {}) {
  const stockRatio = Math.max(4, Math.min(100, Math.round((p.stock / 60) * 100)));
  const low = p.stock <= 15;
  const wished = state.wishlist.has(p.slug);
  return `
  <article class="product" data-slug="${p.slug}">
    <div class="product__media">
      <a href="#/produit/${p.slug}" aria-label="${escapeHtml(p.name)}">
        <img src="${p.image}" alt="${escapeHtml(p.name)} — ${escapeHtml(p.brand)}" width="520" height="560" loading="lazy">
      </a>
      <div class="product__badges">
        <span class="badge">-${p.discount} %</span>
        ${p.badges.includes('Best-seller') ? '<span class="badge badge--soft">★ Best-seller</span>' : ''}
      </div>
      <button class="product__wish ${wished ? 'is-on' : ''}" data-act="wish" data-slug="${p.slug}" aria-label="Ajouter aux favoris">${wished ? '♥' : '♡'}</button>
      <div class="product__quick">
        <button class="btn btn--block btn--sm" data-act="add" data-slug="${p.slug}">${icon('cart')} Ajouter au panier</button>
      </div>
    </div>
    <div class="product__body">
      <span class="product__brand">${escapeHtml(p.brand)} · ${escapeHtml(p.category)}</span>
      <h3 class="product__name"><a href="#/produit/${p.slug}">${escapeHtml(p.name)}</a></h3>
      ${wide ? `<p class="product__hook">${escapeHtml(p.hook)}</p>` : ''}
      <div class="product__rating">${stars(p.rating)} <span>${p.rating.toFixed(1)} · ${eur0.format(p.reviewCount)} avis</span></div>
      <div class="product__prices">
        <span class="product__now">${money(p.price)}</span>
        <s class="product__was">${money(p.compare)}</s>
        <span class="product__save">−${money(p.compare - p.price)}</span>
      </div>
      <div class="product__stock">
        <span class="product__sold">${icon('fire')} ${p.soldToday} vendus aujourd’hui</span>
        ${low ? `<div style="color:var(--hot);font-weight:600;margin-top:6px">Plus que ${p.stock} en stock</div>` : ''}
        <div class="bar"><i style="width:${stockRatio}%"></i></div>
      </div>
    </div>
  </article>`;
}

function skeletons(count = 8) {
  return `<div class="grid-products">${'<div class="skeleton" style="height:420px"></div>'.repeat(count)}</div>`;
}

/* ------------------------------------------------------------- 8. Vues --- */

async function viewHome(main) {
  main.innerHTML = `
    <section class="hero">
      <div class="container hero__grid">
        <div>
      <span class="eyebrow">Black Friday 2026 · ${escapeHtml(state.event.phase)}</span>
      <h1>Le drop tech qui <span class="hl">divise les prix</span> par deux.</h1>
          <p class="hero__lead">${state.event.productCount || 34} références sélectionnées et testées en laboratoire, jusqu’à −${state.event.maxDiscount} % pendant ${state.event.name}. Stock réel, pas d’écran de fumée : quand c’est parti, c’est parti.</p>

          <div class="hero__cta">
            <a class="btn btn--lg" href="#/boutique?sort=discount">Voir les remises ${icon('arrow')}</a>
            <a class="btn btn--ghost btn--lg" href="#/boutique">Explorer le catalogue</a>
          </div>

          <div class="hero__stats">
            <div class="hero__stat"><b>−${state.event.maxDiscount} %</b><span>remise maximale</span></div>
            <div class="hero__stat"><b class="mono" data-countdown-text>--</b><span>avant la fin des offres</span></div>
            <div class="hero__stat"><b>24 h</b><span>expédition chrono</span></div>
          </div>
        </div>

        <div class="hero__stage" id="hero-stage"></div>
      </div>
    </section>

    <section class="section--tight"><div class="container" id="flash-slot"></div></section>

    <section class="section--tight">
      <div class="container">
        <div class="cats" id="cats-slot">
          ${(state.event.categories || []).map((c) => `
            <a class="cat" href="#/boutique?cat=${encodeURIComponent(c.category)}">
              <b>${escapeHtml(c.category)}</b><span>${c.count} références</span>
            </a>`).join('')}
        </div>
      </div>
    </section>

    <section class="section">
      <div class="container">
        <div class="section-head">
          <div>
            <h2>Les pièces qu’on nous arrache</h2>
            <p>Sélection mise en avant par l’équipe VOLT : meilleur rapport remise / qualité perçue du catalogue.</p>
          </div>
          <a class="btn btn--ghost" href="#/boutique?sort=popular">Tout voir ${icon('arrow')}</a>
        </div>
        <div class="grid-products" id="featured-grid">${skeletons(8)}</div>
      </div>
    </section>

    <section class="section--tight">
      <div class="container trust">
        ${[
          ['truck', 'Expédition en 24 h', 'Commandé avant 20 h, expédié le jour même depuis Cotonou.'],
          ['shield', 'Garantie 3 ans', 'Prise en charge SAV par nos techniciens, échange sous 5 jours.'],
          ['return', 'Retour gratuit 30 jours', 'Étiquette prépayée incluse dans chaque colis.'],
          ['lock', 'Paiement 100 % sécurisé', 'MTN MoMo, Moov Money, Wave et carte bancaire — 3D Secure.'],
        ].map(([ic, title, text]) => `
          <div class="trust__item">${icon(ic)}
            <div><b>${title}</b><span>${text}</span></div>
          </div>`).join('')}
      </div>
    </section>

    <section class="section">
      <div class="container">
        <div class="section-head"><div><h2>Ils ont acheté pendant le drop</h2></div></div>
        <div class="grid-reviews" id="reviews-slot"></div>
      </div>
    </section>

    <section class="section--tight">
      <div class="container newsletter">
        <div>
          <h2 style="margin-bottom:8px">Recevez les offres 2 h avant tout le monde</h2>
          <p class="muted" style="margin:0">Les drops partent en moyenne en 3 h 20. Les inscrits reçoivent le lien en premier et un code de 10 % immédiat.</p>
        </div>
        <div>
          <form id="newsletter-form">
            <input type="email" name="email" placeholder="votre@email.com" aria-label="Adresse e-mail" required>
            <button class="btn" type="submit">Je m’inscris</button>
          </form>
          <small>1 e-mail par semaine maximum. Désinscription en un clic.</small>
        </div>
      </div>
    </section>`;

  // Chargements asynchrones (la page s’affiche immédiatement)
  api('/api/flash').then((flash) => {
    state.flash = flash;
    $('#flash-slot').innerHTML = flashBanner(flash);
  }).catch(() => {});

  api('/api/products?sort=discount&limit=8').then(({ items }) => {
    $('#featured-grid').innerHTML = items.map((p) => productCard(p)).join('');
    $('#hero-stage').innerHTML = heroStage(items[0]);
  }).catch(() => { $('#featured-grid').innerHTML = '<p class="muted">Catalogue indisponible.</p>'; });

  api('/api/social-proof').then(({ recent }) => {
    $('#reviews-slot').innerHTML = testimonials(recent);
  }).catch(() => {});
}

function heroStage(product) {
  if (!product) return '';
  return `
    <div class="hero__float hero__float--a"><b>−${product.discount} %</b>aujourd’hui seulement</div>
    <div class="hero__float hero__float--b"><b>${eur0.format(product.soldToday)}</b>vendus aujourd’hui</div>
    <a class="hero__card" href="#/produit/${product.slug}">
      <img src="${product.image}" alt="${escapeHtml(product.name)}" width="520" height="560">
      <div class="hero__card-info">
        <span class="badge badge--volt">N°1 des ventes</span>
        <h3 style="margin-top:10px" class="hero__card-title">${escapeHtml(product.name)}</h3>
        <div class="hero__price"><b>${money(product.price)}</b><s>${money(product.compare)}</s></div>
      </div>
    </a>`;
}

function flashBanner(flash) {
  return `
    <div class="flash">
      <img src="${flash.product.image}" alt="${escapeHtml(flash.product.name)}" width="92" height="92">
      <div>
        <span class="flash__tag">${icon('bolt')} Offre flash du jour</span>
        <h3>${escapeHtml(flash.product.name)}</h3>
        <div class="flash__meta">
          Jusqu’à <b style="color:var(--volt)">−${flash.product.discount + flash.extraPercent} %</b> cumulés ·
          rotation dans <span class="mono" data-countdown-until="${flash.endsAt}">--</span>
        </div>
        <div style="margin-top:10px;max-width:320px">
          <div class="flash__meta">${flash.claimedPercent} % du stock déjà réservé</div>
          <div class="progress" style="margin-top:6px"><div class="progress__bar" style="width:${flash.claimedPercent}%"></div></div>
        </div>
      </div>
      <div class="flash__right">
        <div class="flash__code">Code <code>${flash.code}</code></div>
        <a class="btn btn--hot" href="#/produit/${flash.product.slug}">J’en profite</a>
      </div>
    </div>`;
}

function testimonials(recent) {
  const quotes = [
    ['Élodie R.', 5, 'Commandé pendant le Black Friday', 'Casque reçu en 36 h, emballage soigné. La remise était réelle : j’avais suivi le prix depuis deux mois.'],
    ['Bruno K.', 5, 'Service client impeccable', 'Un câble manquant, remplacé sans discussion en 24 h. C’est rare, je recommande sans réserve.'],
    ['Sarah M.', 4, 'Rapport qualité-prix imbattable', 'Le site est clair, on sait exactement ce qu’on paie et combien on économise. Livraison un peu lente le samedi.'],
    ['Nizar B.', 5, 'Je reviendrai l’an prochain', 'J’ai comparé trois enseignes : c’était le meilleur prix sur les cinq références de ma liste.'],
  ];
  return quotes.map(([author, rating, title, body], i) => `
    <article class="review">
      <div class="review__head">
        <div>
          <div class="review__author">${author}</div>
          <span class="review__verified">${icon('check')} Achat vérifié${recent[i] ? ` · ${escapeHtml(recent[i].city || 'Cotonou')}` : ''}</span>
        </div>
        ${stars(rating)}
      </div>
      <div class="review__title">${title}</div>
      <p class="review__body">${body}</p>
    </article>`).join('');
}

async function viewShop(main, query) {
  const cat = query.get('cat') || '';
  const q = query.get('q') || '';
  const sort = query.get('sort') || 'discount';
  const deals = query.get('deals') === '1';
  const page = Number(query.get('page')) || 1;

  main.innerHTML = `
    <div class="container page-head">
      <span class="eyebrow">Catalogue Black Friday</span>
      <h1>${cat ? escapeHtml(cat) : deals ? 'Remises supérieures à 50 %' : 'Toutes les offres'}</h1>
      <p>Prix TTC, remise appliquée immédiatement au panier. Stock mis à jour en temps réel — les quantités affichées sont celles réellement disponibles.</p>
    </div>
    <section class="section--tight">
      <div class="container">
        <div class="toolbar">
          <div class="filters">
            <a class="chip ${!cat && !deals ? 'is-active' : ''}" href="#/boutique">Tout</a>
            ${(state.event.categories || []).map((c) => `
              <a class="chip ${cat === c.category ? 'is-active' : ''}" href="#/boutique?cat=${encodeURIComponent(c.category)}">${escapeHtml(c.category)}</a>`).join('')}
            <a class="chip ${deals ? 'is-active' : ''}" href="#/boutique?deals=1">−50 % et plus</a>
          </div>
          <span class="spacer"></span>
          <span class="toolbar__count" id="toolbar-count">Chargement…</span>
          <select id="sort-select" aria-label="Trier les résultats">
            <option value="discount" ${sort === 'discount' ? 'selected' : ''}>Remise la plus forte</option>
            <option value="popular" ${sort === 'popular' ? 'selected' : ''}>Les plus vendus</option>
            <option value="price" ${sort === 'price' ? 'selected' : ''}>Prix croissant</option>
            <option value="-price" ${sort === '-price' ? 'selected' : ''}>Prix décroissant</option>
            <option value="rating" ${sort === 'rating' ? 'selected' : ''}>Les mieux notés</option>
            <option value="new" ${sort === 'new' ? 'selected' : ''}>Nouveautés</option>
          </select>
        </div>
        <div id="shop-results">${skeletons(12)}</div>
      </div>
    </section>`;

  const params = new URLSearchParams({ limit: '24', page: String(page), sort });
  if (cat) params.set('cat', cat);
  if (q) params.set('q', q);
  if (deals) params.set('deals', '1');

  const data = await api(`/api/products?${params}`, { silent: true });
  $('#toolbar-count').textContent = `${data.total} référence${data.total > 1 ? 's' : ''}${q ? ` pour « ${q} »` : ''}`;

  const results = $('#shop-results');
  results.innerHTML = data.items.length
    ? `<div class="grid-products grid-products--wide">${data.items.map((p) => productCard(p, { wide: true })).join('')}</div>
       ${data.pages > 1 ? `<div class="pagination">${Array.from({ length: data.pages }, (_, i) => {
         const qs = new URLSearchParams(query); qs.set('page', i + 1);
         return `<button class="${i + 1 === data.page ? 'is-active' : ''}" data-act="goto" data-href="#/boutique?${qs}">${i + 1}</button>`;
       }).join('')}</div>` : ''}`
    : `<div class="empty-state">
         <h2>Aucun résultat</h2>
         <p class="muted">Essayez un autre mot-clé ou élargissez la catégorie.</p>
         <a class="btn" href="#/boutique">Voir toutes les offres</a>
       </div>`;

  $('#sort-select').addEventListener('change', (event) => {
    const qs = new URLSearchParams(query);
    qs.set('sort', event.target.value);
    qs.delete('page');
    location.hash = `#/boutique?${qs}`;
  });
}

async function viewProduct(main, slug) {
  main.innerHTML = `<div class="container section">${skeletons(2)}</div>`;
  const p = await api(`/api/products/${slug}`, { silent: true });
  const selected = { variant: p.variants[0]?.value ?? '', qty: 1 };

  const imageFor = (variant) => `${p.image}${variant ? `?v=${encodeURIComponent(variant)}` : ''}`;
  const unitPrice = () => p.price + (p.variants.find((v) => v.value === selected.variant)?.delta || 0);

  main.innerHTML = `
    <div class="container">
      <nav class="breadcrumb">
        <a href="#/">Accueil</a> <span>/</span>
        <a href="#/boutique?cat=${encodeURIComponent(p.category)}">${escapeHtml(p.category)}</a> <span>/</span>
        <span class="muted">${escapeHtml(p.name)}</span>
      </nav>
    </div>

    <div class="container pdp">
      <div class="pdp__gallery">
        <div class="pdp__main">
          <img id="pdp-image" src="${imageFor(selected.variant)}" alt="${escapeHtml(p.name)}" width="520" height="560">
          <div class="product__badges" style="top:16px;left:16px">
            <span class="badge">-${p.discount} %</span>
            <span class="badge badge--volt">Stock : ${p.stock}</span>
          </div>
        </div>
        <div class="pdp__thumbs">
          ${p.variants.map((v, i) => `
            <button class="${i === 0 ? 'is-active' : ''}" data-act="variant" data-value="${escapeHtml(v.value)}" title="${escapeHtml(v.value)}">
              <img src="${imageFor(v.value)}" alt="Finition ${escapeHtml(v.value)}" width="74" height="74" loading="lazy">
            </button>`).join('')}
        </div>
      </div>

      <div class="pdp__info">
        <span class="eyebrow">${escapeHtml(p.brand)}</span>
        <h1 class="pdp__title">${escapeHtml(p.name)}</h1>
        <div class="pdp__brandline">
          ${stars(p.rating)} <span>${p.rating.toFixed(1)}/5</span> ·
          <a href="#tab-reviews" data-act="tab" data-tab="reviews">${eur0.format(p.reviewCount)} avis vérifiés</a> ·
          <span>Réf. ${String(p.id).padStart(5, '0')}</span>
        </div>
        <p class="pdp__hook">${escapeHtml(p.hook)}</p>

        <div class="pdp__pricebox">
          <div class="pdp__prices">
            <span class="pdp__now" id="pdp-price">${money(unitPrice())}</span>
            <s class="pdp__was">${money(p.compare)}</s>
            <span class="badge">Économisez ${money(p.compare - unitPrice())}</span>
          </div>
          <div class="pdp__vat">Prix TTC, TVA 20 % incluse · payez en 3× ${money(Math.round(unitPrice() / 3))} sans frais</div>

          <div class="pdp__urgency">
            <div class="row">${icon('fire')} <b>${eur0.format(p.soldToday)} exemplaires</b> vendus dans les dernières 24 h</div>
            <div class="row">${icon('bolt')} <b>${p.viewers} personnes</b> consultent cette fiche en ce moment</div>
            <div class="progress" style="margin-top:4px"><div class="progress__bar" style="width:${Math.max(8, Math.min(100, Math.round((1 - p.stock / 120) * 100)))}%"></div></div>
          </div>
        </div>

        <div class="opt-group">
          <div class="opt-group__head"><b>${escapeHtml(p.variants[0]?.group || 'Configuration')}</b><span id="variant-label">${escapeHtml(selected.variant)}</span></div>
          <div class="opt-list">
            ${p.variants.map((v, i) => `
              <button class="opt ${i === 0 ? 'is-active' : ''}" data-act="variant" data-value="${escapeHtml(v.value)}">
                ${escapeHtml(v.value)}${v.delta ? `<small>+ ${money(v.delta)}</small>` : '<small>Inclus</small>'}
              </button>`).join('')}
          </div>
        </div>

        <div class="opt-group">
          <div class="opt-group__head"><b>Quantité</b><span>Maximum 10 par commande</span></div>
          <div class="qty">
            <button data-act="pdp-qty" data-delta="-1" aria-label="Diminuer">−</button>
            <b id="pdp-qty">1</b>
            <button data-act="pdp-qty" data-delta="1" aria-label="Augmenter">+</button>
          </div>
        </div>

        <div class="pdp__actions">
          <button class="btn btn--lg" data-act="pdp-add">${icon('cart')} Ajouter au panier</button>
          <button class="btn btn--lg btn--hot" data-act="pdp-buy">Acheter en 1 clic ${icon('arrow')}</button>
        </div>

        <div class="pdp__perks">
          <div>${icon('truck')}<span><b>Livraison offerte dès 50 000 F.</b> Expédition sous 24 h ouvrées, suivi en temps réel.</span></div>
          <div>${icon('return')}<span><b>Retour gratuit 30 jours.</b> Étiquette prépayée incluse, remboursement en 48 h.</span></div>
          <div>${icon('shield')}<span><b>Garantie constructeur 3 ans</b> + garantie légale. SAV basé à Cotonou.</span></div>
          <div>${icon('lock')}<span><b>Paiement sécurisé.</b> MTN MoMo, Moov Money, Wave, carte bancaire — cryptage TLS 1.3.</span></div>
        </div>
      </div>
    </div>

    <div class="container tabs" id="tabs">
      <div class="tabs__nav">
        <button class="is-active" data-act="tab" data-tab="desc">Description</button>
        <button data-act="tab" data-tab="specs">Caractéristiques</button>
        <button data-act="tab" data-tab="reviews">Avis (${eur0.format(p.reviewCount)})</button>
        <button data-act="tab" data-tab="ship">Livraison &amp; retours</button>
      </div>
      <div data-panel="desc">
        <p style="max-width:70ch">${escapeHtml(p.description)}</p>
      </div>
      <div data-panel="specs" hidden>
        <table class="spec-table"><tbody>
          ${p.specs.map(([k, v]) => `<tr><td>${escapeHtml(k)}</td><td>${escapeHtml(v)}</td></tr>`).join('')}
          <tr><td>Garantie</td><td>3 ans pièces et main-d’œuvre</td></tr>
        </tbody></table>
      </div>
      <div data-panel="reviews" id="tab-reviews" hidden>
        <div class="rating-summary">
          <div>
            <div class="rating-summary__score">${p.rating.toFixed(1)}</div>
            ${stars(p.rating)}
            <div class="muted" style="font-size:.78rem">${eur0.format(p.reviewCount)} avis</div>
          </div>
          <div class="rating-summary__bars">
            ${[5, 4, 3, 2, 1].map((n) => {
              const share = n === 5 ? 78 : n === 4 ? 15 : n === 3 ? 5 : n === 2 ? 1.5 : 0.5;
              return `<div><span>${n} ★</span><div class="progress"><div class="progress__bar" style="width:${share}%"></div></div><span>${share} %</span></div>`;
            }).join('')}
          </div>
          <div style="max-width:200px" class="muted">98 % des acheteurs recommandent ce produit à un proche.</div>
        </div>
        <div class="grid-reviews">
          ${p.reviews.map((r) => `
            <article class="review">
              <div class="review__head">
                <div><div class="review__author">${escapeHtml(r.author)}</div>
                  <span class="review__verified">${icon('check')} Achat vérifié</span></div>
                ${stars(r.rating)}
              </div>
              <div class="review__title">${escapeHtml(r.title)}</div>
              <p class="review__body">${escapeHtml(r.body)}</p>
              <div class="review__date" style="margin-top:8px">${dateFr(r.created_at)}</div>
            </article>`).join('')}
        </div>
      </div>
      <div data-panel="ship" hidden>
        <table class="spec-table"><tbody>
          <tr><td>Expédition standard</td><td>Gratuite dès 50 000 F, sinon ${money(state.event.shippingCost)} — 24 à 48 h à Cotonou et environs</td></tr>
          <tr><td>Expédition express</td><td>5 000 F — livraison le jour même à Cotonou (commande avant 12 h)</td></tr>
          <tr><td>Retour</td><td>30 jours, étiquette prépayée, remboursement sous 48 h après réception</td></tr>
          <tr><td>Garantie</td><td>3 ans constructeur + garantie légale de conformité 2 ans</td></tr>
          <tr><td>Paiement</td><td>MTN MoMo, Moov Money, Wave, carte bancaire</td></tr>
        </tbody></table>
      </div>
    </div>

    <section class="section">
      <div class="container">
        <div class="section-head"><div><h2>Complétez votre installation</h2></div></div>
        <div class="grid-products">${p.relay.map((r) => productCard(r)).join('')}</div>
      </div>
    </section>`;

  // Interactions locales de la fiche produit (assignation, pas d’empilement d’écouteurs)
  const root = main;
  root.onclick = async (event) => {
    const trigger = event.target.closest('[data-act]');
    if (!trigger || !root.contains(trigger)) return;
    const act = trigger.dataset.act;

    if (act === 'variant') {
      selected.variant = trigger.dataset.value;
      $$('.opt', root).forEach((b) => b.classList.toggle('is-active', b.dataset.value === selected.variant));
      $$('.pdp__thumbs button', root).forEach((b) => b.classList.toggle('is-active', b.dataset.value === selected.variant));
      $('#variant-label', root).textContent = selected.variant;
      $('#pdp-image', root).src = imageFor(selected.variant);
      $('#pdp-price', root).textContent = money(unitPrice());
    }

    if (act === 'pdp-qty') {
      selected.qty = Math.max(1, Math.min(10, selected.qty + Number(trigger.dataset.delta)));
      $('#pdp-qty', root).textContent = selected.qty;
    }

    if (act === 'pdp-add') await addToCart(p.slug, selected.variant, selected.qty);
    if (act === 'pdp-buy') await addToCart(p.slug, selected.variant, selected.qty, { buyNow: true });

    if (act === 'tab') {
      const tab = trigger.dataset.tab;
      $$('.tabs__nav button', root).forEach((b) => b.classList.toggle('is-active', b.dataset.tab === tab));
      $$('[data-panel]', root).forEach((panel) => { panel.hidden = panel.dataset.panel !== tab; });
      if (tab === 'reviews') $('#tab-reviews', root)?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  };
}

async function viewCheckout(main) {
  await refreshCart();
  if (!state.cart.items.length) {
    main.innerHTML = `<div class="container empty-state section">
        <h2>Votre panier est vide</h2>
        <p class="muted">Ajoutez au moins un article pour passer commande.</p>
        <a class="btn" href="#/boutique">Voir les offres Black Friday</a>
      </div>`;
    return;
  }

  main.innerHTML = `
    <div class="container">
      <div class="steps">
        <span class="is-active"><i>1</i> Panier</span>
        <span><i>2</i> Livraison &amp; paiement</span>
        <span><i>3</i> Confirmation</span>
      </div>
      <h1 style="margin-bottom:6px">Finaliser ma commande</h1>
      <p class="muted">Vous n’avez pas besoin de créer un compte : le suivi se fait avec votre numéro de commande et votre e-mail.</p>
    </div>

    <form class="container checkout" id="checkout-form" novalidate>
      <div>
        <div class="form-block">
          <h3><i>1</i> Vos coordonnées</h3>
          <div class="form-grid">
            <div class="field"><label for="firstName">Prénom *</label><input id="firstName" name="firstName" autocomplete="given-name" required><span class="error"></span></div>
            <div class="field"><label for="lastName">Nom *</label><input id="lastName" name="lastName" autocomplete="family-name" required><span class="error"></span></div>
            <div class="field"><label for="email">Adresse e-mail *</label><input id="email" name="email" type="email" autocomplete="email" required><span class="error"></span></div>
            <div class="field"><label for="phone">Téléphone</label><input id="phone" name="phone" type="tel" autocomplete="tel" placeholder="Pour la livraison express"><span class="error"></span></div>
          </div>
        </div>

        <div class="form-block">
          <h3><i>2</i> Adresse de livraison</h3>
          <div class="form-grid">
            <div class="field span-2"><label for="address">Adresse *</label><input id="address" name="address" autocomplete="street-address" required><span class="error"></span></div>
            <div class="field"><label for="zip">Code postal *</label><input id="zip" name="zip" inputmode="numeric" autocomplete="postal-code" required><span class="error"></span></div>
            <div class="field"><label for="city">Ville *</label><input id="city" name="city" autocomplete="address-level2" required><span class="error"></span></div>
            <div class="field span-2"><label for="note">Instructions de livraison (optionnel)</label><textarea id="note" name="note" rows="2" placeholder="Code d’entrée, étage, gardien…"></textarea><span class="error"></span></div>
          </div>
        </div>

        <div class="form-block">
          <h3><i>3</i> Paiement</h3>
          <div class="pay-options" id="pay-options">
            ${[
              ['momo', 'MTN MoMo', 'Mobile Money — validation par code sur votre téléphone'],
              ['moov', 'Moov Money', 'Mobile Money Moov Africa — confirmation par SMS'],
              ['wave', 'Wave', 'Paiement instantané sans frais depuis l’application Wave'],
              ['carte', 'Carte bancaire', 'Visa, Mastercard — 3D Secure activé'],
            ].map(([value, title, text], i) => `
              <label class="pay-option ${i === 0 ? 'is-active' : ''}">
                <input type="radio" name="paymentMethod" value="${value}" ${i === 0 ? 'checked' : ''}>
                <span><b>${title}</b><small>${text}</small></span>
              </label>`).join('')}
          </div>
          <div class="form-grid" style="margin-top:16px">
            <div class="field"><label for="card">Numéro Mobile Money</label><input id="card" inputmode="tel" placeholder="97 00 00 00" autocomplete="tel"><span class="error"></span></div>
            <div class="field"><label for="exp">Nom du titulaire</label><input id="exp" placeholder="Prénom NOM" autocomplete="name"><span class="error"></span></div>
          </div>
          <p class="muted" style="font-size:.76rem;margin-top:12px">Démonstration : aucun paiement réel n’est effectué et aucune donnée bancaire n’est enregistrée.</p>
        </div>
      </div>

      <aside class="summary">
        <h3>Récapitulatif (${cartCount()} article${cartCount() > 1 ? 's' : ''})</h3>
        <div class="summary__lines">
          ${state.cart.items.map((line) => `
            <div class="summary__line">
              <img src="${line.image}" alt="" width="54" height="60">
              <div><div>${escapeHtml(line.name)}</div><span class="muted" style="font-size:.76rem">${escapeHtml(line.variant)} × ${line.qty}</span></div>
              <b>${money(line.lineTotal)}</b>
            </div>`).join('')}
        </div>
        <div class="totals">
          <div class="totals__row"><span>Sous-total</span><span class="mono">${money(state.cart.totals.subtotal)}</span></div>
          ${state.cart.totals.discount ? `<div class="totals__row totals__row--save"><span>Remise</span><span class="mono">−${money(state.cart.totals.discount)}</span></div>` : ''}
          <div class="totals__row"><span>Livraison</span><span class="mono">${state.cart.totals.shipping ? money(state.cart.totals.shipping) : 'Offerte'}</span></div>
          <div class="totals__row"><span>dont TVA</span><span class="mono">${money(state.cart.totals.tax)}</span></div>
          <div class="totals__row totals__row--total"><span>Total</span><span class="mono">${money(state.cart.totals.total)}</span></div>
        </div>
        <div class="promo-row" style="margin-top:14px">
          <input id="checkout-promo" placeholder="Code promo" value="${state.promo ? escapeHtml(state.promo.code) : ''}">
          <button type="button" class="btn btn--ghost btn--sm" data-act="applyPromo-checkout">OK</button>
        </div>
        <button class="btn btn--block btn--lg" type="submit" style="margin-top:16px">Payer ${money(state.cart.totals.total)}</button>
        <div class="trust-note">${icon('lock')} Transaction chiffrée · aucune donnée bancaire conservée</div>
        <div class="trust-note">${icon('return')} Satisfait ou remboursé 30 jours</div>
        <div class="trust-note">${icon('shield')} Garantie 3 ans sur tous les produits</div>
      </aside>
    </form>`;

  $$('#pay-options .pay-option').forEach((label) => {
    label.addEventListener('click', () => {
      $$('#pay-options .pay-option').forEach((l) => l.classList.remove('is-active'));
      label.classList.add('is-active');
    });
  });

  $('#checkout-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const form = event.target;
    $$('.field', form).forEach((f) => { f.classList.remove('is-invalid'); $('.error', f).textContent = ''; });

    const data = Object.fromEntries(new FormData(form));
    const body = {
      customer: {
        email: data.email, firstName: data.firstName, lastName: data.lastName,
        address: data.address, zip: data.zip, city: data.city,
        phone: data.phone || '', note: data.note || '',
      },
      paymentMethod: data.paymentMethod || 'carte',
      promoCode: state.promo?.code || '',
    };

    // Validation locale immédiate (l’API revalide de toute façon)
    const localErrors = {};
    for (const key of ['firstName', 'lastName', 'email', 'address', 'zip', 'city']) {
      if (!String(body.customer[key] || '').trim()) localErrors[key] = 'Champ obligatoire.';
    }
    if (!localErrors.email && !/^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(body.customer.email)) localErrors.email = 'Adresse e-mail invalide.';
    if (!localErrors.zip && !/^\d{4,6}$/.test(body.customer.zip)) localErrors.zip = 'Code postal invalide.';

    if (Object.keys(localErrors).length) {
      for (const [key, message] of Object.entries(localErrors)) {
        const field = $(`#${key}`)?.closest('.field');
        if (field) { field.classList.add('is-invalid'); $('.error', field).textContent = message; }
      }
      toast({ title: 'Formulaire incomplet', text: 'Corrigez les champs surlignés.', tone: 'hot' });
      return;
    }

    const submit = $('button[type=submit]', form);
    submit.disabled = true;
    submit.textContent = 'Traitement du paiement…';

    try {
      const result = await api('/api/orders', { method: 'POST', body });
      state.promo = null;
      await refreshCart();
      location.hash = `#/merci/${result.number}`;
    } catch (error) {
      if (error.details) {
        for (const [key, message] of Object.entries(error.details)) {
          const field = $(`#${key}`)?.closest('.field');
          if (field) { field.classList.add('is-invalid'); $('.error', field).textContent = message; }
        }
      }
      submit.disabled = false;
      submit.textContent = `Payer ${money(state.cart.totals.total)}`;
    }
  });
}

async function viewConfirmation(main, number) {
  main.innerHTML = `<div class="container section">${skeletons(2)}</div>`;
  let order;
  try {
    order = await api(`/api/orders/${encodeURIComponent(number)}`, { silent: true });
  } catch {
    main.innerHTML = `<div class="container empty-state section">
      <h2>Commande introuvable</h2>
      <p class="muted">Vérifiez le numéro, ou contactez-nous si le problème persiste.</p>
      <a class="btn" href="#/suivi">Suivre une commande</a></div>`;
    return;
  }

  main.innerHTML = `
    <div class="container confirm">
      <div class="confirm__tick">${icon('check')}</div>
      <h1>Commande confirmée, ${escapeHtml(order.first_name)} !</h1>
      <p class="muted">Merci pour votre confiance. Un e-mail de confirmation part vers <b>${escapeHtml(order.email)}</b> dans quelques instants.</p>
      <div class="confirm__num">${escapeHtml(order.number)}</div>
      <p class="muted" style="font-size:.82rem">Conservez ce numéro : il permet de suivre votre colis à tout moment.</p>

      <div class="timeline">
        ${order.tracking.steps.map((label, i) => `
          <div class="timeline__step ${i <= order.tracking.current ? 'is-done' : ''}"><i>${i <= order.tracking.current ? '✓' : i + 1}</i>${label}</div>`).join('')}
      </div>

      <div class="order-card">
        <div class="order-card__head">
          <div>
            <b>Livraison prévue</b>
            <div class="muted" style="font-size:.84rem">${dateFr(order.tracking.eta)} · ${escapeHtml(order.address)}, ${escapeHtml(order.zip)} ${escapeHtml(order.city)}</div>
          </div>
          <span class="badge badge--volt">${escapeHtml(order.status)}</span>
        </div>
        ${order.items.map((item) => `
          <div class="order-line">
            <img src="/media/${item.slug}.svg" alt="" width="48" height="54">
            <div>
              <a href="#/produit/${item.slug}">${escapeHtml(item.name)}</a>
              <div class="muted" style="font-size:.76rem">${escapeHtml(item.variant)} · quantité ${item.qty}</div>
            </div>
            <b class="mono">${money(item.unit_cents * item.qty)}</b>
          </div>`).join('')}
        <div class="totals" style="margin-top:16px">
          <div class="totals__row"><span>Sous-total</span><span class="mono">${money(order.subtotal_cents)}</span></div>
          ${order.discount_cents ? `<div class="totals__row totals__row--save"><span>Remise ${escapeHtml(order.promo_code)}</span><span class="mono">−${money(order.discount_cents)}</span></div>` : ''}
          <div class="totals__row"><span>Livraison</span><span class="mono">${order.shipping_cents ? money(order.shipping_cents) : 'Offerte'}</span></div>
          <div class="totals__row"><span>dont TVA (20 %)</span><span class="mono">${money(order.tax_cents)}</span></div>
          <div class="totals__row totals__row--total"><span>Total payé</span><span class="mono">${money(order.total_cents)}</span></div>
        </div>
      </div>

      <div class="row" style="justify-content:center;margin-top:24px">
        <a class="btn" href="#/suivi">Suivre ma commande</a>
        <a class="btn btn--ghost" href="#/boutique">Continuer mes achats</a>
        <button class="btn btn--ghost" onclick="window.print()">Imprimer le récapitulatif</button>
      </div>
      <p class="muted" style="font-size:.76rem;margin-top:26px">${icon('gift')} Besoin d’une facture au nom de votre société ? Répondez à l’e-mail de confirmation.</p>
    </div>`;
}

async function viewTracking(main) {
  main.innerHTML = `
    <div class="container page-head center">
      <span class="eyebrow">Service client</span>
      <h1>Suivre ma commande</h1>
      <p class="muted">Saisissez votre numéro de commande (format VOLT-XXXXXX) et l’e-mail utilisé lors de l’achat.</p>
    </div>
    <div class="container section" style="max-width:720px">
      <form class="track-form" id="track-form">
        <input name="number" placeholder="VOLT-XXXXXX" required aria-label="Numéro de commande">
        <input name="email" type="email" placeholder="votre@email.com" required aria-label="Adresse e-mail">
        <button class="btn" type="submit">Rechercher</button>
      </form>
      <div id="track-result" style="margin-top:26px"></div>
    </div>`;

  $('#track-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const data = Object.fromEntries(new FormData(event.target));
    const box = $('#track-result');
    box.innerHTML = skeletons(1);
    try {
      const order = await api(`/api/orders/${encodeURIComponent(data.number.trim())}?email=${encodeURIComponent(data.email.trim())}`, { silent: true });
      box.innerHTML = `
        <div class="order-card">
          <div class="order-card__head">
            <div>
              <b>Commande ${escapeHtml(order.number)}</b>
              <div class="muted" style="font-size:.84rem">Passée le ${dateFr(order.created_at)} · ${order.items.length} article(s)</div>
            </div>
            <span class="badge badge--volt">${escapeHtml(order.status)}</span>
          </div>
          <div class="timeline" style="margin:20px 0">
            ${order.tracking.steps.map((label, i) => `
              <div class="timeline__step ${i <= order.tracking.current ? 'is-done' : ''}"><i>${i <= order.tracking.current ? '✓' : i + 1}</i>${label}</div>`).join('')}
          </div>
          <div class="totals"><div class="totals__row totals__row--total"><span>Total</span><span class="mono">${money(order.total_cents)}</span></div></div>
        </div>`;
    } catch (error) {
      box.innerHTML = `<div class="empty-state"><h2>Aucune commande trouvée</h2><p class="muted">${escapeHtml(error.message)}</p></div>`;
      toast({ title: 'Commande introuvable', text: 'Vérifiez le numéro et l’adresse e-mail.', tone: 'hot' });
    }
  });
}

/* ------------------------------------------------------------ 9. Routeur -- */

function parseHash() {
  const raw = (location.hash || '#/').replace(/^#/, '');
  const [path, qs] = raw.split('?');
  return { path: path || '/', query: new URLSearchParams(qs || '') };
}

async function route() {
  const main = $('#app');
  const { path, query } = parseHash();
  const parts = path.split('/').filter(Boolean);
  main.onclick = null; // les vues qui le souhaitent réinstallent leur propre écouteur
  window.scrollTo(0, 0);

  try {
    if (!parts.length) return await viewHome(main, query);
    if (parts[0] === 'boutique') return await viewShop(main, query);
    if (parts[0] === 'produit' && parts[1]) return await viewProduct(main, decodeURIComponent(parts[1]));
    if (parts[0] === 'commande') return await viewCheckout(main);
    if (parts[0] === 'merci' && parts[1]) return await viewConfirmation(main, decodeURIComponent(parts[1]));
    if (parts[0] === 'suivi') return await viewTracking(main);
    if (parts[0] === 'mentions') return viewLegal(main);

    main.innerHTML = `<div class="container empty-state section">
      <h1>404</h1><p class="muted">Cette page n’existe pas (ou plus).</p>
      <a class="btn" href="#/">Retour à l’accueil</a></div>`;
  } catch (error) {
    console.error(error);
    main.innerHTML = `<div class="container empty-state section">
      <h1>Une erreur est survenue</h1><p class="muted">${escapeHtml(error.message)} — réessayez, ou revenez à l’accueil.</p>
      <a class="btn" href="#/">Retour à l’accueil</a></div>`;
  }
}

function viewLegal(main) {
  main.innerHTML = `
    <div class="container page-head">
      <h1>Mentions légales</h1>
      <p class="muted">Éditeur (Cotonou, Bénin), données personnelles et conditions de la démonstration.</p>
    </div>
    <div class="container section" style="max-width:760px">
      <div class="card" style="padding:28px 30px">
        <h2 style="font-size:1.1rem">Éditeur</h2>
        <p class="muted">VOLT Store — démonstration e-commerce réalisée pour l’événement Black Friday 2026. Cotonou, République du Bénin. Contact : support@volt-demo.example</p>
        <h2 style="font-size:1.1rem">Données personnelles</h2>
        <p class="muted">Les informations saisies (panier, commande, e-mail, numéro Mobile Money) servent uniquement au fonctionnement de cette démonstration et restent sur ce serveur. Aucun partage, aucun envoi réel.</p>
        <h2 style="font-size:1.1rem">Paiement et commandes</h2>
        <p class="muted">Le paiement est simulé (Mobile Money et carte) : aucune transaction réelle n’a lieu, aucun prélèvement n’est effectué. Les commandes et stocks sont persistés localement pour la démonstration.</p>
        <h2 style="font-size:1.1rem">Conditions commerciales</h2>
        <p class="muted">Remises valables du 23 au 30 novembre 2026 dans la limite des stocks disponibles. Prix en francs CFA (XOF), TVA béninoise 18 % incluse. Livraison offerte dès 50 000 F d’achat, retours gratuits 30 jours, garantie constructeur 3 ans.</p>
      </div>
    </div>`;
}

/* ------------------------------------------------------ 10. Interactions -- */

document.addEventListener('click', async (event) => {
  const trigger = event.target.closest('[data-act]');
  if (!trigger) {
    // Fermeture du tiroir en cliquant à côté
    if (event.target.closest('#cart-btn')) openDrawer();
    return;
  }
  const act = trigger.dataset.act;

  switch (act) {
    case 'openCart': openDrawer(); break;
    case 'closeCart': closeDrawer(); break;
    case 'add': await addToCart(trigger.dataset.slug, undefined, 1); break;
    case 'wish': {
      const slug = trigger.dataset.slug;
      if (state.wishlist.has(slug)) { state.wishlist.delete(slug); trigger.classList.remove('is-on'); trigger.textContent = '♡'; }
      else { state.wishlist.add(slug); trigger.classList.add('is-on'); trigger.textContent = '♥'; toast({ title: 'Ajouté à vos favoris', text: 'Retrouvez-le à votre prochaine visite.' }); }
      saveWish();
      break;
    }
    case 'qty': {
      const line = state.cart.items.find((i) => String(i.id) === trigger.dataset.line);
      if (!line) break;
      const qty = Math.max(0, line.qty + Number(trigger.dataset.delta));
      const data = await api(`/api/cart/${line.id}`, { method: 'PATCH', body: { qty }, silent: true }).catch(() => null);
      if (data) { state.cart = { items: data.items, totals: data.totals }; renderCartBadge(); renderDrawer(); }
      break;
    }
    case 'removeLine': {
      const data = await api(`/api/cart/${trigger.dataset.line}`, { method: 'DELETE', silent: true }).catch(() => null);
      if (data) { state.cart = { items: data.items, totals: data.totals }; renderCartBadge(); renderDrawer(); toast({ title: 'Article retiré', text: 'Votre panier a été mis à jour.' }); }
      break;
    }
    case 'applyPromo': {
      const code = $('#promo-input')?.value?.trim();
      if (!code) break;
      try {
        const data = await api('/api/promo', { method: 'POST', body: { code } });
        state.promo = data.promo;
        state.cart = { items: data.items, totals: data.totals };
        renderDrawer();
        toast({ title: `Code ${data.promo.code} appliqué`, text: `Vous économisez ${money(data.totals.discount || 0)}.` });
      } catch { /* toast déjà affiché */ }
      break;
    }
    case 'clearPromo': {
      state.promo = null;
      await refreshCart();
      toast({ title: 'Code promo retiré', text: 'Le panier repasse au prix Black Friday.' });
      break;
    }
    case 'applyPromo-checkout': {
      const code = $('#checkout-promo')?.value?.trim();
      if (!code) break;
      try {
        const data = await api('/api/promo', { method: 'POST', body: { code } });
        state.promo = data.promo;
        state.cart = { items: data.items, totals: data.totals };
        toast({ title: `Code ${data.promo.code} appliqué`, text: `Vous économisez ${money(data.totals.discount || 0)}.` });
        await route();
      } catch { /* toast déjà affiché */ }
      break;
    }
    case 'goto': location.hash = trigger.dataset.href; break;
    case 'dismissModal': $('#modal-root').innerHTML = ''; break;
    default: break;
  }
});

$('#drawer-close').addEventListener('click', closeDrawer);
$('#scrim').addEventListener('click', closeDrawer);
document.addEventListener('keydown', (event) => { if (event.key === 'Escape') closeDrawer(); });

$('#search-form').addEventListener('submit', (event) => {
  event.preventDefault();
  const term = $('#search-input').value.trim();
  location.hash = term ? `#/boutique?q=${encodeURIComponent(term)}` : '#/boutique';
});

// Newsletter (délégué : le formulaire est re-rendu à chaque navigation)
document.addEventListener('submit', async (event) => {
  if (!event.target.matches('#newsletter-form')) return;
  event.preventDefault();
  const email = new FormData(event.target).get('email');
  try {
    const data = await api('/api/newsletter', { method: 'POST', body: { email } });
    toast({ title: 'Inscription confirmée', text: data.message, action: 'Code <b>FLASH10</b> à utiliser dès maintenant.' });
    event.target.reset();
  } catch { /* toast déjà affiché */ }
});

// Relance sur intention de sortie : une seule fois par session
let exitShown = sessionStorage.getItem('volt_exit') === '1';
document.addEventListener('mouseout', (event) => {
  if (exitShown || event.relatedTarget || event.clientY > 8) return;
  exitShown = true;
  sessionStorage.setItem('volt_exit', '1');
  showExitModal();
});

function showExitModal() {
  const root = $('#modal-root');
  root.innerHTML = `
    <div class="modal" data-act="dismissModal">
      <div class="modal__box" role="dialog" aria-modal="true" aria-labelledby="exit-title">
        <button class="icon-btn modal__close" data-act="dismissModal" aria-label="Fermer">${icon('close')}</button>
        <span class="eyebrow">Avant que vous partiez</span>
        <h2 id="exit-title">Vous laissez −10 % supplémentaires sur la table</h2>
        <p class="muted">Votre panier n’est pas encore validé. Ce code s’ajoute aux remises Black Friday déjà affichées et reste valable jusqu’à minuit.</p>
        <div class="modal__code"><code>FLASH10</code></div>
        <button class="btn btn--block btn--lg" data-act="dismissModal">J’en profite maintenant ${icon('arrow')}</button>
        <p class="muted center" style="font-size:.76rem;margin:14px 0 0">Livraison offerte dès 50 000 F · retours gratuits 30 jours</p>
      </div>
    </div>`;
  // « J’en profite » : on ferme et on ouvre le panier pour ramener au tunnel d’achat.
  root.querySelector('.modal__box .btn').addEventListener('click', () => setTimeout(openDrawer, 10));
}

/* ------------------------------------------------------------ 11. Départ -- */

addEventListener('hashchange', route);

(async function boot() {
  try {
    state.event = await api('/api/event', { silent: true });
  } catch {
    state.event = { phase: 'en cours', maxDiscount: 70, freeShippingThreshold: 8000, shippingCost: 590, productCount: 34, endsAt: new Date(Date.now() + 864e5).toISOString(), categories: [] };
  }
  try { await refreshCart(); } catch { /* l’API répondra plus tard */ }
  await route();
  tickCountdown();
  setInterval(tickCountdown, 1000);

  // Preuve sociale discrète, uniquement sur les pages de vente
  setInterval(() => {
    if (!['/', '/boutique'].includes(parseHash().path)) return;
    const cities = ['Cotonou', 'Porto-Novo', 'Abomey-Calavi', 'Parakou', 'Bohicon', 'Natitingou', 'Ouidah', 'Djougou'];
    const names = ['Julien', 'Aïcha', 'Marc', 'Sandra', 'Antoine', 'Léa', 'Karim', 'Camille'];
    const city = cities[Math.floor(Math.random() * cities.length)];
    const name = names[Math.floor(Math.random() * names.length)];
    if (state.socialSeen.has(`${name}${city}`)) return;
    state.socialSeen.add(`${name}${city}`);
    toast({ title: `${name} de ${city} vient de commander`, text: `il y a ${1 + Math.floor(Math.random() * 9)} min · livraison en 24 h`, iconName: 'check' });
  }, 22000);
})();
