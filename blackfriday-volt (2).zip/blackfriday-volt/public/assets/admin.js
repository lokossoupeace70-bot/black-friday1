/* ============================================================ admin.js ====
   Console d’exploitation VOLT : stock, commandes, remises, statistiques.
   ========================================================================= */

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

/* Montants en FCFA entiers (XOF) — pas de division par 100. */
const xof = new Intl.NumberFormat('fr-FR', { style: 'currency', currency: 'XOF' });
const money = (cents) => xof.format(cents || 0).replace(/\u202f/g, ' ');
const num = (n) => new Intl.NumberFormat('fr-FR').format(n || 0);
const esc = (t) => String(t ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const STATUS_CLASS = { 'en préparation': 'prep', 'expédiée': 'ship', 'livrée': 'done', 'annulée': 'cancel' };
const statusTag = (status) => `<span class="status status--${STATUS_CLASS[status] || 'prep'}">${esc(status)}</span>`;

let token = sessionStorage.getItem('volt_admin') || '';

/* ----------------------------------------------------------- transport --- */

async function call(path, { method = 'GET', body } = {}) {
  const res = await fetch(path, {
    method,
    headers: { 'x-admin-token': token, ...(body ? { 'Content-Type': 'application/json' } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
  const payload = await res.json().catch(() => ({}));
  if (res.status === 401 && path !== '/api/admin/login') { logout(); throw new Error('Session expirée.'); }
  if (!res.ok) { toast(payload.error || 'Erreur', 'hot'); throw new Error(payload.error || 'Erreur'); }
  return payload;
}

function toast(text, tone = 'volt') {
  const node = document.createElement('div');
  node.className = 'toast';
  node.innerHTML = `<span class="toast__icon" style="${tone === 'hot' ? 'background:var(--hot-soft);color:var(--hot)' : ''}">✓</span><div><b>${esc(text)}</b></div>`;
  $('#toasts').append(node);
  setTimeout(() => node.remove(), 3200);
}

/* --------------------------------------------------------------- login --- */

$('#login-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const password = $('#password').value;
  try {
    const res = await fetch('/api/admin/login', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password }),
    });
    const payload = await res.json();
    if (!res.ok) throw new Error(payload.error || 'Connexion refusée.');
    token = payload.token;
    sessionStorage.setItem('volt_admin', token);
    enterConsole();
  } catch (error) {
    $('#login-error').textContent = error.message;
  }
});

function logout() {
  token = '';
  sessionStorage.removeItem('volt_admin');
  $('#admin-app').hidden = true;
  $('#login-screen').hidden = false;
}

$('#logout').addEventListener('click', logout);

function enterConsole() {
  $('#login-screen').hidden = true;
  $('#admin-app').hidden = false;
  loadDashboard();
  loadOrders();
  loadProducts();
  loadPromos();
}

/* ------------------------------------------------------------- onglets --- */

const TITLES = {
  dashboard: ['Vue d’ensemble', 'Performance de la campagne Black Friday en temps réel.'],
  orders: ['Commandes', 'Préparation, expédition et suivi des colis clients.'],
  products: ['Catalogue & stock', 'Ajustez les prix et les quantités sans redéployer la boutique.'],
  promos: ['Codes promo', 'Créez et pilotez les remises de la campagne.'],
};

$$('.admin-nav nav button').forEach((button) => {
  button.addEventListener('click', () => {
    $$('.admin-nav nav button').forEach((b) => b.classList.toggle('is-active', b === button));
    const tab = button.dataset.tab;
    $$('[data-view]').forEach((view) => { view.hidden = view.dataset.view !== tab; });
    $('#view-title').textContent = TITLES[tab][0];
    $('#view-sub').textContent = TITLES[tab][1];
  });
});

/* ---------------------------------------------------------- vue synthèse -- */

async function loadDashboard() {
  const stats = await call('/api/admin/stats');

  $('#kpis').innerHTML = `
    <div class="kpi kpi--accent"><span>Chiffre d’affaires</span><b>${money(stats.revenue)}</b><small>${num(stats.orders)} commande(s) payée(s)</small></div>
    <div class="kpi"><span>Aujourd’hui</span><b>${money(stats.today)}</b><small>encaissé depuis minuit</small></div>
    <div class="kpi"><span>Panier moyen</span><b>${money(stats.aov)}</b><small>${num(stats.items)} article(s) vendu(s)</small></div>
    <div class="kpi"><span>Taux de conversion</span><b>${Number(stats.conversion).toLocaleString('fr-FR')} %</b><small>${num(stats.visitors)} ajouts au panier</small></div>`;

  const days = stats.salesByDay.length ? stats.salesByDay : [{ day: new Date().toISOString().slice(0, 10), orders: 0, revenue: 0 }];
  const max = Math.max(...days.map((d) => d.revenue), 1);
  $('#chart').innerHTML = days.map((day) => {
    const label = new Date(day.day).toLocaleDateString('fr-FR', { day: '2-digit', month: '2-digit' });
    return `<div class="chart__bar" title="${label} — ${money(day.revenue)} (${day.orders} cmd)">
      <b>${day.revenue ? money(day.revenue) : ''}</b>
      <i style="height:${Math.max(4, Math.round((day.revenue / max) * 100))}%"></i>
      <span>${label}</span>
    </div>`;
  }).join('');

  const catMax = Math.max(...stats.categories.map((c) => c.revenue), 1);
  $('#cat-breakdown').innerHTML = stats.categories.length
    ? `<div class="meta-list">${stats.categories.map((c) => `
        <div class="meta-list__row">
          <span>${esc(c.category)}</span><b>${money(c.revenue)}</b>
          <div class="bar"><i style="width:${Math.round((c.revenue / catMax) * 100)}%"></i></div>
        </div>`).join('')}</div>`
    : '<p class="muted">Aucune vente enregistrée pour le moment.</p>';

  $('#top-products').innerHTML = stats.topProducts.length
    ? `<thead><tr><th>Produit</th><th>Qté</th><th>CA</th></tr></thead><tbody>
        ${stats.topProducts.map((p) => `<tr>
          <td><img class="thumb" src="/media/${p.slug}.svg" alt=""> ${esc(p.name)}</td>
          <td>${num(p.qty)}</td><td><b>${money(p.revenue)}</b></td></tr>`).join('')}</tbody>`
    : '<tbody><tr><td class="muted">Aucune vente enregistrée.</td></tr></tbody>';

  $('#low-stock').innerHTML = stats.lowStock.length
    ? stats.lowStock.map((p) => `<div class="stock-alert">
        <img src="/media/${p.slug}.svg" alt="">
        <span>${esc(p.name)}</span><b>${p.stock} restant(s)</b>
      </div>`).join('')
    : '<p class="muted">Tous les stocks sont au-dessus du seuil d’alerte. 👌</p>';
}

/* ------------------------------------------------------------ commandes -- */

async function loadOrders() {
  const search = $('#order-search').value.trim();
  const status = $('#order-status').value;
  const params = new URLSearchParams();
  if (search) params.set('q', search);
  if (status) params.set('status', status);
  const { orders } = await call(`/api/admin/orders?${params}`);

  $('#orders-table').innerHTML = orders.length
    ? `<thead><tr><th>Numéro</th><th>Client</th><th>Ville</th><th>Promo</th><th>Total</th><th>Date</th><th>Statut</th></tr></thead><tbody>
        ${orders.map((o) => `<tr>
          <td><b>${esc(o.number)}</b></td>
          <td>${esc(o.first_name)} ${esc(o.last_name)}<br><span class="muted" style="font-size:.75rem">${esc(o.email)}</span></td>
          <td>${esc(o.city)}</td>
          <td>${o.promo_code ? `<code>${esc(o.promo_code)}</code>` : '<span class="muted">—</span>'}</td>
          <td><b>${money(o.total_cents)}</b></td>
          <td>${new Date(o.created_at).toLocaleString('fr-FR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}</td>
          <td>
            ${statusTag(o.status)}
            <select data-order="${o.id}" style="margin-top:6px">
              ${['en préparation', 'expédiée', 'livrée', 'annulée'].map((s) => `<option ${s === o.status ? 'selected' : ''}>${s}</option>`).join('')}
            </select>
          </td>
        </tr>`).join('')}</tbody>`
    : '<tbody><tr><td class="muted">Aucune commande ne correspond à cette recherche.</td></tr></tbody>';

  $$('#orders-table select[data-order]').forEach((select) => {
    select.addEventListener('change', async () => {
      await call(`/api/admin/orders/${select.dataset.order}`, { method: 'PATCH', body: { status: select.value } });
      toast(`Commande mise à jour : ${select.value}`);
      loadOrders();
      loadDashboard();
    });
  });
}

$('#order-search').addEventListener('input', debounce(loadOrders, 320));
$('#order-status').addEventListener('change', loadOrders);

/* ------------------------------------------------------------ catalogue -- */

async function loadProducts() {
  const q = $('#product-search').value.trim();
  const { products } = await call(`/api/admin/products?q=${encodeURIComponent(q)}`);

  $('#products-table').innerHTML = `<thead><tr><th>Produit</th><th>Prix de vente</th><th>Prix barré</th><th>Stock</th><th>Mise en avant</th></tr></thead><tbody>
    ${products.map((p) => `<tr>
      <td><div class="row" style="gap:10px;flex-wrap:nowrap"><img class="thumb" src="/media/${p.slug}.svg" alt="">
        <span><b>${esc(p.name)}</b><br><span class="muted" style="font-size:.75rem">${esc(p.brand)} · ${esc(p.category)}</span></span></div></td>
      <td><input type="number" value="${p.price_cents}" min="0" step="100" data-edit="price" data-id="${p.id}"> <span class="muted" style="font-size:.75rem">${money(p.price_cents)}</span></td>
      <td class="muted">${money(p.compare_cents)}</td>
      <td><input type="number" value="${p.stock}" min="0" data-edit="stock" data-id="${p.id}"></td>
      <td><input type="checkbox" data-edit="featured" data-id="${p.id}" ${p.featured ? 'checked' : ''} style="accent-color:var(--volt);width:18px;height:18px"></td>
    </tr>`).join('')}</tbody>`;

  $$('#products-table input[data-edit]').forEach((input) => {
    input.addEventListener('change', async () => {
      const field = input.dataset.edit;
      const body = field === 'featured' ? { featured: input.checked } : { [field]: Number(input.value) };
      await call(`/api/admin/products/${input.dataset.id}`, { method: 'PATCH', body });
      toast('Fiche produit mise à jour');
      loadProducts();
      loadDashboard();
    });
  });
}

$('#product-search').addEventListener('input', debounce(loadProducts, 320));

/* --------------------------------------------------------------- promos -- */

async function loadPromos() {
  const { promos } = await call('/api/admin/promos');
  $('#promos-table').innerHTML = `<thead><tr><th>Code</th><th>Libellé</th><th>Type</th><th>Valeur</th><th>Minimum</th><th>Utilisations</th><th></th></tr></thead><tbody>
    ${promos.map((p) => `<tr>
      <td><code>${esc(p.code)}</code></td>
      <td>${esc(p.label)}</td>
      <td>${p.kind === 'percent' ? 'Pourcentage' : p.kind === 'amount' ? 'Montant fixe' : 'Livraison offerte'}</td>
      <td>${p.kind === 'percent' ? `−${p.value} %` : p.kind === 'amount' ? money(p.value) : '—'}</td>
      <td>${p.min_cents ? money(p.min_cents) : '—'}</td>
      <td>${num(p.uses)}${p.max_uses ? ` / ${num(p.max_uses)}` : ''}</td>
      <td><button class="btn btn--ghost btn--sm" data-del="${esc(p.code)}">Supprimer</button></td>
    </tr>`).join('')}</tbody>`;

  $$('#promos-table button[data-del]').forEach((button) => {
    button.addEventListener('click', async () => {
      await call(`/api/admin/promos/${button.dataset.del}`, { method: 'DELETE' });
      toast('Code promo supprimé');
      loadPromos();
    });
  });
}

$('#promo-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(event.target));
  await call('/api/admin/promos', {
    method: 'POST',
    body: {
      code: data.code, label: data.label, kind: data.kind,
      value: Number(data.value), min: Number(data.min), maxUses: Number(data.maxUses),
    },
  });
  toast('Code promo créé');
  event.target.reset();
  loadPromos();
});

/* --------------------------------------------------------------- divers -- */

function debounce(fn, delay) {
  let timer;
  return (...args) => { clearTimeout(timer); timer = setTimeout(() => fn(...args), delay); };
}

$('#refresh').addEventListener('click', () => {
  loadDashboard(); loadOrders(); loadProducts(); loadPromos();
  toast('Données actualisées');
});

/* Compte à rebours identique à celui de la boutique */
let endsAt = null;
fetch('/api/event').then((r) => r.json()).then((event) => { endsAt = event.endsAt; tick(); setInterval(tick, 1000); });

function tick() {
  if (!endsAt) return;
  const left = Math.max(0, new Date(endsAt).getTime() - Date.now());
  const value = {
    d: Math.floor(left / 864e5),
    h: Math.floor((left % 864e5) / 36e5),
    m: Math.floor((left % 36e5) / 6e4),
    s: Math.floor((left % 6e4) / 1000),
  };
  for (const [unit, v] of Object.entries(value)) {
    const el = $(`[data-cd="${unit}"]`);
    if (el) el.textContent = String(v).padStart(2, '0');
  }
}

/* Reprise automatique de session si le jeton est toujours valide */
if (token) {
  call('/api/admin/stats').then(enterConsole).catch(() => logout());
}
