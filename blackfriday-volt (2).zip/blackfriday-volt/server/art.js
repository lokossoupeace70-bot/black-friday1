/**
 * art.js — visuels produits générés (SVG vectoriel, aucun asset externe).
 * Chaque produit reçoit une composition déterministe : dégradé de marque,
 * halo lumineux, silhouette d'appareil et trame technique.
 */
import crypto from 'node:crypto';

const PALETTES = [
  ['#c6ff2f', '#0b2f1f', '#04140d'],
  ['#ff6a2b', '#2b0d0b', '#140604'],
  ['#4dd8ff', '#062033', '#02121d'],
  ['#b58cff', '#180a33', '#0a0518'],
  ['#ff3d6e', '#2d0616', '#16030b'],
  ['#ffd166', '#2e2205', '#150f02'],
  ['#54f2b0', '#04241c', '#01120d'],
  ['#8fa3ff', '#0b1030', '#050817'],
];

/**
 * Un coloris nommé doit se voir dans le visuel : chaque mot-clé de finition
 * est relié à une palette. C’est ce qui rend la galerie produit cohérente.
 */
const PALETTE_BY_FINISH = [
  [/noir|minuit|carbone|encre/i, ['#9fb0c2', '#14181e', '#07090c']],
  [/blanc|perle|arctique|argent|ivoire/i, ['#e9f1fa', '#1b222c', '#0b0f14']],
  [/vert|volt|lime|menthe/i, ['#c6ff2f', '#0b2f1f', '#04140d']],
  [/gris|titane|anthracite|acier/i, ['#93a6bb', '#131922', '#080b10']],
  [/rouge|corail|cerise/i, ['#ff4d3d', '#2b0d0b', '#160604']],
  [/or|doré|champagne|laiton/i, ['#ffc247', '#2e2205', '#150f02']],
  [/bleu|azur|océan|nuit/i, ['#4dd8ff', '#062033', '#02121d']],
  [/violet|prune|lavande/i, ['#b58cff', '#180a33', '#0a0518']],
  [/rose|fuchsia|magenta/i, ['#ff5fa8', '#2d0616', '#16030b']],
  [/bois|terracotta|sable|beige/i, ['#d9a066', '#2a1d12', '#130d07']],
];

function paletteFor(variant, hash) {
  if (variant) {
    for (const [pattern, palette] of PALETTE_BY_FINISH) {
      if (pattern.test(variant)) return palette;
    }
  }
  return PALETTES[hash % PALETTES.length];
}

const SILHOUETTES = {
  Audio: (c) => `
    <path d="M150 300 v-58 a110 110 0 0 1 220 0 v58" fill="none" stroke="${c}" stroke-width="26" stroke-linecap="round"/>
    <rect x="112" y="286" width="76" height="128" rx="34" fill="${c}"/>
    <rect x="332" y="286" width="76" height="128" rx="34" fill="${c}"/>
    <circle cx="150" cy="350" r="9" fill="#04070c" opacity=".55"/>
    <circle cx="370" cy="350" r="9" fill="#04070c" opacity=".55"/>`,
  Gaming: (c) => `
    <path d="M170 380 q-58 0 -74 -62 l-16 -62 q-10 -42 34 -50 q34 -6 58 22 h156 q24 -28 58 -22 q44 8 34 50 l-16 62 q-16 62 -74 62 z" fill="${c}"/>
    <circle cx="212" cy="330" r="30" fill="#04070c" opacity=".45"/>
    <circle cx="308" cy="330" r="30" fill="#04070c" opacity=".45"/>
    <rect x="290" y="256" width="16" height="44" rx="8" fill="#04070c" opacity=".4"/>
    <rect x="276" y="270" width="44" height="16" rx="8" fill="#04070c" opacity=".4"/>`,
  Informatique: (c) => `
    <rect x="126" y="196" width="268" height="176" rx="18" fill="${c}"/>
    <rect x="146" y="216" width="228" height="136" rx="8" fill="#04070c" opacity=".5"/>
    <path d="M92 386 h336 l26 34 q6 12 -10 12 h-368 q-16 0 -10 -12 z" fill="${c}" opacity=".85"/>
    <path d="M170 300 h180 M170 330 h120" stroke="${c}" stroke-width="10" stroke-linecap="round" opacity=".55"/>`,
  'Maison connectée': (c) => `
    <rect x="176" y="196" width="168" height="232" rx="80" fill="${c}"/>
    <circle cx="260" cy="266" r="34" fill="#04070c" opacity=".45"/>
    <path d="M232 372 q28 22 56 0" stroke="#04070c" stroke-width="10" fill="none" opacity=".4" stroke-linecap="round"/>
    <circle cx="260" cy="330" r="7" fill="#04070c" opacity=".5"/>`,
  Mobile: (c) => `
    <rect x="182" y="168" width="156" height="288" rx="34" fill="${c}"/>
    <rect x="198" y="190" width="124" height="230" rx="20" fill="#04070c" opacity=".5"/>
    <circle cx="240" cy="212" r="10" fill="#04070c" opacity=".45"/>
    <circle cx="272" cy="212" r="10" fill="#04070c" opacity=".45"/>
    <circle cx="260" cy="446" r="12" fill="${c}"/>`,
  'Photo & Vidéo': (c) => `
    <rect x="128" y="212" width="264" height="176" rx="30" fill="${c}"/>
    <path d="M206 212 l18 -34 h72 l18 34 z" fill="${c}"/>
    <circle cx="260" cy="300" r="58" fill="#04070c" opacity=".55"/>
    <circle cx="260" cy="300" r="30" fill="${c}" opacity=".8"/>
    <circle cx="348" cy="248" r="13" fill="#04070c" opacity=".5"/>`,
};

// `>>> 0` est indispensable : sans lui, les décalages de bits peuvent produire
// un index négatif et faire planter le générateur de visuels.
const hashOf = (text) => (parseInt(crypto.createHash('sha256').update(text).digest('hex').slice(0, 8), 16) >>> 0);

/**
 * @returns {string} document SVG complet
 */
export function productArt({ slug, category, brand = '', name = '', variant = '' }) {
  const h = hashOf(slug);
  const [accent, mid, deep] = paletteFor(variant, h);
  const silhouette = SILHOUETTES[category] || SILHOUETTES.Mobile;
  const rot = ((h >>> 7) % 7) - 3;
  const gid = `g${h.toString(16).slice(0, 6)}`;

  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 520 560" width="520" height="560" role="img" aria-label="${escapeXml(name)}">
  <defs>
    <linearGradient id="${gid}-bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="${mid}"/><stop offset="1" stop-color="${deep}"/>
    </linearGradient>
    <radialGradient id="${gid}-glow" cx="50%" cy="42%" r="60%">
      <stop offset="0" stop-color="${accent}" stop-opacity=".42"/>
      <stop offset="1" stop-color="${accent}" stop-opacity="0"/>
    </radialGradient>
    <linearGradient id="${gid}-obj" x1="0" y1="0" x2="0.4" y2="1">
      <stop offset="0" stop-color="#ffffff"/><stop offset="0.35" stop-color="${accent}"/>
      <stop offset="1" stop-color="${accent}" stop-opacity=".72"/>
    </linearGradient>
    <pattern id="${gid}-grid" width="26" height="26" patternUnits="userSpaceOnUse">
      <path d="M26 0 H0 V26" fill="none" stroke="${accent}" stroke-opacity=".10" stroke-width="1"/>
    </pattern>
  </defs>

  <rect width="520" height="560" fill="url(#${gid}-bg)"/>
  <rect width="520" height="560" fill="url(#${gid}-grid)"/>
  <rect width="520" height="560" fill="url(#${gid}-glow)"/>

  <circle cx="430" cy="96" r="118" fill="${accent}" opacity=".07"/>
  <circle cx="86" cy="470" r="150" fill="${accent}" opacity=".05"/>

  <!-- Monogramme utilisé comme texture : aucun texte lisible, donc aucun conflit
       avec les badges et les titres ajoutés par la boutique par-dessus. -->
  <text x="260" y="352" text-anchor="middle" font-family="'Segoe UI',system-ui,sans-serif"
        font-size="320" font-weight="800" fill="${accent}" fill-opacity=".055" letter-spacing="-10">${escapeXml((brand || 'BF').slice(0, 2).toUpperCase())}</text>

  <g transform="rotate(${rot} 260 300)" opacity=".97">
    ${silhouette(`url(#${gid}-obj)`)}
  </g>

  <!-- Réflecteur discret sous l’appareil, pour asseoir la silhouette. -->
  <ellipse cx="260" cy="472" rx="150" ry="20" fill="${deep}" opacity=".55"/>
  <ellipse cx="260" cy="470" rx="104" ry="13" fill="${accent}" opacity=".13"/>
</svg>`;
}

function escapeXml(text) {
  return String(text).replace(/[<>&"']/g, (ch) => ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', '"': '&quot;', "'": '&apos;' }[ch]));
}
