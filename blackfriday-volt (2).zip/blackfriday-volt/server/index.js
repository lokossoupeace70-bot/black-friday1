/**
 * index.js — point d’entrée du serveur VOLT.
 * Sert l’API JSON, les visuels produits générés et le frontend statique.
 */
import http from 'node:http';
import { api } from './routes.js';
import { json, serveStatic, HttpError } from './core.js';
import { eventWindow } from './event.js';

const PORT = Number(process.env.PORT) || 4100;
const HOST = process.env.HOST || '127.0.0.1';

const server = http.createServer(async (req, res) => {
  const started = process.hrtime.bigint();
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = url.pathname;

  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'same-origin');

  try {
    const match = api.match(req.method, pathname);

    if (match && match.methodNotAllowed) {
      return json(res, 405, { error: `Méthode ${req.method} non autorisée sur ${pathname}.` });
    }

    if (match) {
      const body = ['POST', 'PUT', 'PATCH'].includes(req.method) ? await readBody(req) : null;
      return await match.route.handler(req, res, match.params, url, body);
    }

    if (req.method === 'GET' || req.method === 'HEAD') {
      if (await serveStatic(req, res, pathname)) return;
      if (!pathname.startsWith('/api/')) {
        // Route inconnue côté interface : on renvoie l’application (routage côté client).
        if (await serveStatic(req, res, '/index.html')) return;
      }
      return json(res, 404, { error: 'Not found' });
    }

    return json(res, 404, { error: 'Not found' });
  } catch (error) {
    if (error instanceof HttpError) {
      return json(res, error.status, { error: error.message, details: error.details ?? null });
    }
    console.error('[volt] erreur inattendue', error);
    return json(res, 500, { error: 'Erreur interne du serveur.' });
  } finally {
    done();
  }

  function done() {
    if (res.__voltLogged) return;
    res.__voltLogged = true;
    const ms = Number(process.hrtime.bigint() - started) / 1e6;
    if (process.env.VOLT_LOG !== 'off') {
      console.log(`${req.method} ${pathname} → ${res.statusCode} (${ms.toFixed(1)} ms)`);
    }
  }
});

async function readBody(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  if (!chunks.length) return {};
  try {
    const parsed = JSON.parse(Buffer.concat(chunks).toString('utf8'));
    if (parsed === null || typeof parsed !== 'object') throw new Error('not an object');
    return parsed;
  } catch {
    throw new HttpError(400, 'JSON invalide dans le corps de la requête.');
  }
}

server.listen(PORT, HOST, () => {
  const win = eventWindow();
  console.log('');
  console.log('  ⚡  VOLT — Black Friday tech store');
  console.log(`      http://${HOST}:${PORT}`);
  console.log(`      admin : http://${HOST}:${PORT}/admin.html  (mot de passe : ${process.env.ADMIN_PASSWORD || 'blackfriday2026'})`);
  console.log(`      campagne : ${win.name} · phase « ${win.phase} » · fin ${win.endsAt.slice(0, 10)}`);
  console.log('');
});

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => {
    console.log('\n[volt] arrêt du serveur.');
    server.close(() => process.exit(0));
  });
}

export { server };
