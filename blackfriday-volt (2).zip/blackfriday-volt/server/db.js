/**
 * db.js — schéma SQLite + catalogue de démarrage.
 * Utilise le module natif `node:sqlite` (Node >= 22.5) : aucune dépendance à installer.
 */
import { DatabaseSync } from 'node:sqlite';
import path from 'node:path';
import { DATA_DIR, mulberry32, slugify } from './core.js';

export const DB_PATH = process.env.VOLT_DB || path.join(DATA_DIR, 'volt.sqlite');

export const db = new DatabaseSync(DB_PATH);
db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;');

/* ============================================================== SCHÉMA ==== */

db.exec(`
CREATE TABLE IF NOT EXISTS products (
  id            INTEGER PRIMARY KEY,
  slug          TEXT UNIQUE NOT NULL,
  name          TEXT NOT NULL,
  brand         TEXT NOT NULL,
  category      TEXT NOT NULL,
  hook          TEXT NOT NULL,
  description   TEXT NOT NULL,
  price_cents   INTEGER NOT NULL,
  compare_cents INTEGER NOT NULL,
  stock         INTEGER NOT NULL,
  rating        REAL    NOT NULL,
  review_count  INTEGER NOT NULL,
  sold_today    INTEGER NOT NULL DEFAULT 0,
  featured      INTEGER NOT NULL DEFAULT 0,
  badges        TEXT    NOT NULL DEFAULT '[]',
  specs         TEXT    NOT NULL DEFAULT '[]',
  created_at    TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_products_cat ON products(category);

CREATE TABLE IF NOT EXISTS variants (
  id           INTEGER PRIMARY KEY,
  product_id   INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  group_name   TEXT NOT NULL,
  value        TEXT NOT NULL,
  price_delta  INTEGER NOT NULL DEFAULT 0,
  stock        INTEGER NOT NULL DEFAULT 0,
  sort_order   INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_variants_product ON variants(product_id);

CREATE TABLE IF NOT EXISTS reviews (
  id          INTEGER PRIMARY KEY,
  product_id  INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  author      TEXT NOT NULL,
  rating      INTEGER NOT NULL,
  title       TEXT NOT NULL,
  body        TEXT NOT NULL,
  verified    INTEGER NOT NULL DEFAULT 1,
  created_at  TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_reviews_product ON reviews(product_id);

CREATE TABLE IF NOT EXISTS cart_items (
  id          INTEGER PRIMARY KEY,
  cart_id     TEXT NOT NULL,
  product_id  INTEGER NOT NULL REFERENCES products(id) ON DELETE CASCADE,
  variant     TEXT NOT NULL DEFAULT '',
  qty         INTEGER NOT NULL,
  added_at    TEXT NOT NULL,
  UNIQUE(cart_id, product_id, variant)
);

CREATE TABLE IF NOT EXISTS promos (
  code       TEXT PRIMARY KEY,
  label      TEXT NOT NULL,
  kind       TEXT NOT NULL,              -- percent | amount | freeship
  value      INTEGER NOT NULL DEFAULT 0,
  min_cents  INTEGER NOT NULL DEFAULT 0,
  max_uses   INTEGER NOT NULL DEFAULT 0, -- 0 = illimité
  uses       INTEGER NOT NULL DEFAULT 0,
  active     INTEGER NOT NULL DEFAULT 1
);

CREATE TABLE IF NOT EXISTS orders (
  id              INTEGER PRIMARY KEY,
  number          TEXT UNIQUE NOT NULL,
  email           TEXT NOT NULL,
  first_name      TEXT NOT NULL,
  last_name       TEXT NOT NULL,
  address         TEXT NOT NULL,
  zip             TEXT NOT NULL,
  city            TEXT NOT NULL,
  country         TEXT NOT NULL DEFAULT 'Bénin',
  phone           TEXT NOT NULL DEFAULT '',
  note            TEXT NOT NULL DEFAULT '',
  payment_method  TEXT NOT NULL DEFAULT 'carte',
  subtotal_cents  INTEGER NOT NULL,
  discount_cents  INTEGER NOT NULL DEFAULT 0,
  shipping_cents  INTEGER NOT NULL DEFAULT 0,
  tax_cents       INTEGER NOT NULL DEFAULT 0,
  total_cents     INTEGER NOT NULL,
  promo_code      TEXT NOT NULL DEFAULT '',
  status          TEXT NOT NULL DEFAULT 'en préparation',
  created_at      TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_orders_email ON orders(email);

CREATE TABLE IF NOT EXISTS order_items (
  id           INTEGER PRIMARY KEY,
  order_id     INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  product_id   INTEGER NOT NULL,
  name         TEXT NOT NULL,
  slug         TEXT NOT NULL,
  variant      TEXT NOT NULL DEFAULT '',
  unit_cents   INTEGER NOT NULL,
  qty          INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id);

CREATE TABLE IF NOT EXISTS newsletter (
  email      TEXT PRIMARY KEY,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS stats_events (
  id         INTEGER PRIMARY KEY,
  kind       TEXT NOT NULL,
  label      TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL
);
`);

/* ============================================================= CATALOGUE == */

const CATEGORIES = ['Audio', 'Gaming', 'Informatique', 'Maison connectée', 'Mobile', 'Photo & Vidéo'];

/** [nom, marque, catégorie, accroche, prixVente FCFA, prixBarre FCFA, stock, note, avis, vendusAujourd'hui, mise en avant] */
/* Prix en FCFA (XOF) — les colonnes `*_cents` contiennent des francs CFA entiers. */
const CATALOG = [
  ['Casque Volt One Pro ANC', 'Voltek', 'Audio', 'Le silence absolu, 60 h d’autonomie et un son signé Voltek.', 118000, 229500, 42, 4.8, 1284, 311, 1],
  ['Écouteurs Volt Buds Air 3', 'Voltek', 'Audio', 'Réduction de bruit adaptative dans un format invisible.', 59000, 131000, 130, 4.6, 942, 508, 1],
  ['Enceinte Nordwave Boom 360', 'Nordwave', 'Audio', 'Son à 360°, étanche IP67, 30 h de fête non-stop.', 78500, 164000, 58, 4.7, 431, 174, 0],
  ['Barre de son Nordwave Cine 5.1', 'Nordwave', 'Audio', 'Un cinéma Dolby Atmos dans 90 cm de salon.', 164000, 361000, 21, 4.5, 208, 63, 0],
  ['Casque Studio Aurex Monitor', 'Aurex', 'Audio', 'Moniteurs de studio pour le mixage et la production.', 131000, 236000, 17, 4.9, 156, 41, 0],
  ['Micro USB Aurex Stream Pro', 'Aurex', 'Audio', 'Micro cardioïde broadcast, prêt à l’emploi en 10 secondes.', 49000, 98500, 64, 4.4, 311, 122, 0],

  ['Console portable Kairo Deck X', 'Kairo', 'Gaming', 'Le PC de jeu tenu dans une main, 120 Hz en 1080p.', 361000, 590500, 12, 4.7, 687, 96, 1],
  ['Manette Kairo Elite Pro', 'Kairo', 'Gaming', 'Sticks hall-effect, gâchettes réglables, zéro drift.', 46000, 92000, 96, 4.8, 1502, 402, 1],
  ['Casque gaming Pulse Arena 7.1', 'Pulse', 'Gaming', 'Audio spatial 7.1 et micro détachable à réduction de bruit.', 65500, 131000, 71, 4.5, 823, 264, 0],
  ['Clavier mécanique Pulse Strike TKL', 'Pulse', 'Gaming', 'Switches hot-swap, PCB en aluminium, 8 000 Hz.', 72000, 124500, 44, 4.6, 372, 141, 0],
  ['Souris Pulse Edge 26K', 'Pulse', 'Gaming', 'Capteur 26 000 DPI, 54 g, 200 h de jeu.', 39500, 78500, 118, 4.7, 1104, 336, 0],
  ['Chaise gaming Ferro Throne', 'Ferro', 'Gaming', 'Assise ergonomique 12 positions, soutien lombaire actif.', 151000, 282000, 26, 4.3, 189, 47, 0],

  ['Ordinateur portable Zento Air 14', 'Zento', 'Informatique', '1,1 kg, écran OLED 3K, 18 h d’autonomie réelle.', 590500, 918500, 18, 4.7, 512, 88, 1],
  ['Zento Book Pro 16 créateur', 'Zento', 'Informatique', 'Puce 12 cœurs et dalle mini-LED calibrée usine.', 951000, 1443500, 9, 4.8, 233, 22, 0],
  ['Écran Lumen View 27 4K', 'Lumen', 'Informatique', '4K 144 Hz, 1 ms, HDR600, 90 W de charge USB-C.', 249500, 459000, 33, 4.6, 401, 118, 1],
  ['SSD externe Ferro Vault 2 To', 'Ferro', 'Informatique', '2 To à 2 000 Mo/s, blindage anti-choc et chiffrement.', 98500, 183500, 87, 4.7, 665, 295, 0],
  ['Station d’accueil Zento Hub 12', 'Zento', 'Informatique', '12 ports, double 4K 60 Hz, Ethernet 2,5 Gb.', 59000, 111500, 109, 4.4, 288, 176, 0],
  ['Imprimante Lumen Print WiFi', 'Lumen', 'Informatique', 'Impression recto-verso, encre rechargeable, 3 ans garantis.', 85500, 151000, 47, 4.2, 214, 58, 0],

  ['Enceinte connectée Lumen Echo Dot+', 'Lumen', 'Maison connectée', 'Assistant vocal, hub domotique et son 360° en cuisine.', 29500, 65500, 156, 4.5, 1877, 642, 1],
  ['Ampoule Lumen Smart Color ×4', 'Lumen', 'Maison connectée', '16 millions de couleurs, scènes automatiques, sans pont.', 23000, 52500, 210, 4.6, 934, 421, 0],
  ['Caméra Orbit Guard 2K', 'Orbit', 'Maison connectée', 'Vision nocturne couleur, IA de détection, stockage local.', 46000, 98500, 92, 4.7, 559, 203, 0],
  ['Robot aspirateur Orbit Sweep S9', 'Orbit', 'Maison connectée', 'Aspire et lave, station auto-vidage 60 jours.', 229500, 459000, 23, 4.8, 712, 148, 1],
  ['Thermostat Orbit Heat Sense', 'Orbit', 'Maison connectée', 'Jusqu’à 27 % d’économie d’énergie, pilotage à distance.', 65500, 118000, 61, 4.4, 341, 97, 0],
  ['Prise connectée Ferro Plug ×2', 'Ferro', 'Maison connectée', 'Mesure la consommation, scénarios horaires, Matter.', 16500, 36000, 240, 4.3, 612, 388, 0],

  ['Smartphone Kairo Edge 6 Pro', 'Kairo', 'Mobile', 'Capteur photo 200 Mpx, écran 144 Hz, charge 120 W.', 426500, 721500, 28, 4.7, 1120, 210, 1],
  ['Smartphone Nordwave Slim 5', 'Nordwave', 'Mobile', 'Le meilleur rapport qualité-prix de la gamme, 4G+.', 151000, 295000, 74, 4.4, 806, 337, 1],
  ['Batterie nomade Ferro Charge 20K', 'Ferro', 'Mobile', '20 000 mAh, 65 W, afficheur et triple sortie.', 26000, 59000, 188, 4.6, 1433, 512, 0],
  ['Montre Kairo Pulse Watch 2', 'Kairo', 'Mobile', 'ECG, SpO₂, GPS double bande, 14 jours d’autonomie.', 118000, 216500, 52, 4.5, 592, 168, 0],
  ['Chargeur Zento Mag 3-en-1', 'Zento', 'Mobile', 'Téléphone, montre et écouteurs sur un seul socle pliable.', 36000, 78500, 133, 4.3, 407, 249, 0],

  ['Appareil photo Orbit Snap M50', 'Orbit', 'Photo & Vidéo', 'Hybride 33 Mpx, vidéo 6K, stabilisation 8 stops.', 492000, 787000, 11, 4.9, 268, 34, 1],
  ['Action cam Orbit Go Extreme', 'Orbit', 'Photo & Vidéo', '6K 60 i/s, étanche 20 m sans caisson, stabilisation horizon.', 183500, 295000, 39, 4.7, 519, 127, 1],
  ['Drone Orbit Sky View Mini', 'Orbit', 'Photo & Vidéo', '249 g, 4K HDR, 34 min de vol, retour automatique.', 282000, 525000, 14, 4.6, 302, 52, 0],
  ['Trépied Aurex Tripod Carbon', 'Aurex', 'Photo & Vidéo', 'Carbone 1,2 kg pliable à 38 cm, rotule fluide.', 78500, 144500, 45, 4.5, 176, 61, 0],
  ['Éclairage Aurex LED Panel Duo', 'Aurex', 'Photo & Vidéo', 'Bi-color 2500-9000 K, batterie intégrée, monture universelle.', 59000, 111500, 68, 4.4, 143, 74, 0],
];

const VARIANT_PRESETS = {
  Audio: { group: 'Finition', values: [['Noir minuit', 0], ['Blanc perle', 0], ['Vert volt', 2500]] },
  Gaming: { group: 'Finition', values: [['Noir carbone', 0], ['Blanc arctique', 0]] },
  Informatique: { group: 'Capacité', values: [['Base', 0], ['1 To', 60000], ['2 To', 120000]] },
  'Maison connectée': { group: 'Finition', values: [['Blanc', 0], ['Gris titane', 0], ['Noir', 0]] },
  Mobile: { group: 'Stockage', values: [['128 Go', 0], ['256 Go', 40000], ['512 Go', 105000]] },
  'Photo & Vidéo': { group: 'Pack', values: [['Boîtier seul', 0], ['Pack créateur', 52000]] },
};

const SPEC_RANGES = {
  Audio: [
    ['Autonomie', 'h', 18, 60], ['Poids', ' g', 160, 320], ['Bluetooth', '5.4 multipoint', null], ['Impédance', ' Ω', 16, 64], ['Charge rapide', '10 min = 5 h', null],
  ],
  Gaming: [
    ['Latence', ' ms', 1, 3], ['Autonomie', 'h', 12, 40], ['Connexion', '2,4 GHz + Bluetooth', null], ['Durabilité', '10 M clics', null], ['Poids', ' g', 54, 320],
  ],
  Informatique: [
    ['Mémoire', ' Go', 16, 64], ['Stockage SSD', ' Go', 512, 2000], ['Garantie', '3 ans', null], ['Connectique', 'Thunderbolt 4 / HDMI 2.1', null], ['Refroidissement', 'Vapor chamber', null],
  ],
  'Maison connectée': [
    ['Compatibilité', 'Matter / Alexa / Google', null], ['Consommation', ' W', 3, 90], ['Portée', ' m', 20, 120], ['Sécurité', 'Chiffrement AES-256', null], ['Installation', 'Aucun abonnement', null],
  ],
  Mobile: [
    ['Écran', ' AMOLED 120 Hz', null], ['Batterie', ' mAh', 4200, 6000], ['Charge', ' W', 33, 120], ['Photo', ' MP', 50, 200], ['Étanchéité', 'IP68', null],
  ],
  'Photo & Vidéo': [
    ['Capteur', ' MP', 20, 61], ['Vidéo', ' up to 6K', null], ['Stabilisation', '5 axes', null], ['Autonomie', ' min', 45, 180], ['Monture', 'Universelle 1/4"', null],
  ],
};

const REVIEW_POOL = [
  ['Léa M.', 5, 'Increvable, je recommande', 'Livrée en 48 h, emballage nickel. La qualité perçue est largement au-dessus du prix payé pendant le Black Friday.'],
  ['Karim B.', 5, 'Le rapport qualité-prix du drop', 'J’attendais cette promo depuis un mois. Aucun regret, la fabrication est sérieuse et la prise en main immédiate.'],
  ['Sofia T.', 4, 'Très bon, un détail à revoir', 'Rien à redire sur les performances. Je retire une étoile pour la notice un peu légère, mais le SAV a répondu en 2 h.'],
  ['Yanis R.', 5, 'Deuxième achat, même modèle', 'J’en ai repris un pour offrir. La différence se sent dès la première utilisation, notamment sur la finition.'],
  ['Camille D.', 5, 'Réellement conforme à la description', 'Les chiffres annoncés sont tenus, testé pendant 3 semaines. Le service client est réactif et humain.'],
  ['Thomas L.', 4, 'Solide, livraison rapide', 'Commandé vendredi, reçu lundi. Le produit fait le job sans fioritures, exactement ce que je cherchais.'],
  ['Nadia H.', 5, 'Parfait pour un cadeau', 'Le packaging fait très haut de gamme. Offert à mon frère qui l’utilise tous les jours depuis.'],
  ['Mehdi A.', 3, 'Bien mais perfectible', 'Globalement satisfait, la finition aurait pu être meilleure sur les angles. Reste excellent pour ce tarif.'],
];

/* ============================================================== SEEDING === */

function specsFor(category, rnd) {
  const rows = SPEC_RANGES[category] || [];
  return rows.map(([label, unit, min, max]) => {
    if (min === null) return [label, unit];
    return [label, `${Math.round(min + rnd() * (max - min))}${unit}`];
  });
}

export function seedIfEmpty({ force = false } = {}) {
  const { n } = db.prepare('SELECT COUNT(*) AS n FROM products').get();
  if (n > 0 && !force) return false;

  if (force) db.exec('DELETE FROM products; DELETE FROM orders; DELETE FROM order_items; DELETE FROM cart_items; DELETE FROM promos;');

  const insertProduct = db.prepare(`
    INSERT INTO products (slug, name, brand, category, hook, description, price_cents, compare_cents,
      stock, rating, review_count, sold_today, featured, badges, specs, created_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`);
  const insertVariant = db.prepare('INSERT INTO variants (product_id, group_name, value, price_delta, stock, sort_order) VALUES (?,?,?,?,?,?)');
  const insertReview = db.prepare('INSERT INTO reviews (product_id, author, rating, title, body, verified, created_at) VALUES (?,?,?,?,?,1,?)');

  const now = new Date().toISOString();

  db.exec('BEGIN');
  try {
    CATALOG.forEach((row, index) => {
      const [name, brand, category, hook, price, was, stock, rating, reviewCount, soldToday, featured] = row;
      const slug = slugify(`${brand} ${name}`);
      const rnd = mulberry32(index * 7919 + 13);

      const badges = [];
      const discount = Math.round((1 - price / was) * 100);
      if (discount >= 50) badges.push(`-${discount} %`);
      if (index % 4 === 0) badges.push('Livraison 24 h');
      if (index % 5 === 0) badges.push('Best-seller');
      if (index % 7 === 0) badges.push('Derniers exemplaires');

      const description = `${hook} Testé et certifié par nos ingénieurs, le ${name} de ${brand} arrive dans la sélection Black Friday VOLT avec sa garantie constructeur complète de 3 ans et un service après-vente basé à Cotonou. Stock limité à ${stock} pièces pour toute la durée de l’événement : les précédents drops ont été épuisés en moins de six heures.`;

      const info = insertProduct.run(
        slug, name, brand, category, hook, description,
        price, was, stock, rating, reviewCount, soldToday,
        featured, JSON.stringify(badges), JSON.stringify(specsFor(category, rnd)), now,
      );
      const productId = Number(info.lastInsertRowid);

      const preset = VARIANT_PRESETS[category];
      preset.values.forEach(([value, delta], i) => {
        const share = Math.max(1, Math.round(stock / preset.values.length));
        insertVariant.run(productId, preset.group, value, delta, share - (i === 0 ? 0 : 0), i);
      });

      const reviewTemplates = REVIEW_POOL.slice(index % 3).concat(REVIEW_POOL).slice(0, 3 + (index % 3));
      reviewTemplates.forEach((r, i) => {
        const [author, stars, title, body] = r;
        const daysAgo = 2 + i * 3 + (index % 9);
        insertReview.run(productId, author, stars, title, body, new Date(Date.now() - daysAgo * 864e5).toISOString());
      });
    });

    const insertPromo = db.prepare('INSERT OR REPLACE INTO promos (code, label, kind, value, min_cents, max_uses, uses, active) VALUES (?,?,?,?,?,?,0,1)');
    insertPromo.run('BLACK20', 'BLACK20 — 20 % sur tout le panier', 'percent', 20, 0, 0);
    insertPromo.run('VOLT30', 'VOLT30 — 30 % dès 200 000 F d’achat', 'percent', 30, 200000, 500);
    insertPromo.run('FREESHIP', 'Livraison offerte', 'freeship', 0, 0, 0);
    insertPromo.run('GAME15', 'GAME15 — 10 000 F sur le rayon gaming', 'amount', 10000, 50000, 0);
    insertPromo.run('FLASH10', 'Offre flash du jour — 10 % supplémentaires', 'percent', 10, 30000, 300);

    db.exec('COMMIT');
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }
  return true;
}

seedIfEmpty();

export { CATEGORIES };

/* =============================================================== QUERIES == */

export function getProduct(idOrSlug) {
  const product = db.prepare('SELECT * FROM products WHERE slug = ? OR id = ?').get(String(idOrSlug), Number(idOrSlug) || -1);
  if (!product) return null;
  return hydrate(product);
}

/**
 * Ajoute les relations à une ligne produit.
 * Les colonnes `badges` / `specs` restent des chaînes JSON : la sérialisation
 * est faite au niveau de l’API, un seul endroit, pour éviter les doubles
 * `JSON.parse` silencieux (qui faisaient planter le détail produit).
 */
export function hydrate(product) {
  const variants = db.prepare('SELECT group_name, value, price_delta, stock FROM variants WHERE product_id = ? ORDER BY sort_order').all(product.id);
  const reviews = db.prepare('SELECT author, rating, title, body, verified, created_at FROM reviews WHERE product_id = ? ORDER BY created_at DESC').all(product.id);
  return {
    ...product,
    variants,
    reviews,
    discount: Math.round((1 - product.price_cents / product.compare_cents) * 100),
  };
}

/** Lecture défensive d’une colonne JSON (chaîne ou déjà désérialisée). */
export function parseColumn(value, fallback = []) {
  if (value == null || value === '') return fallback;
  if (typeof value !== 'string') return value;
  try { return JSON.parse(value); } catch { return fallback; }
}

export function listCategories() {
  return db.prepare('SELECT category, COUNT(*) AS count FROM products GROUP BY category ORDER BY category').all();
}
