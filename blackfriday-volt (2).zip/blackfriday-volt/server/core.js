/**
 * core.js — micro-framework HTTP (zéro dépendance).
 * Routeur, sessions signées, cookies, fichiers statiques, parsing du corps.
 */
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const PUBLIC_DIR = path.join(ROOT, 'public');
export const DATA_DIR = path.join(ROOT, 'data');

fs.mkdirSync(DATA_DIR, { recursive: true });

/* ------------------------------------------------------------------ utils */

const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp',
  '.avif': 'image/avif',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.txt': 'text/plain; charset=utf-8',
  '.map': 'application/json; charset=utf-8',
};

/* ---------------------------------------------------------- clé de session */

const SECRET_FILE = path.join(DATA_DIR, '.session-secret');
function loadSecret() {
  if (process.env.SESSION_SECRET) return process.env.SESSION_SECRET;
  try {
    const existing = fs.readFileSync(SECRET_FILE, 'utf8').trim();
    if (existing.length >= 32) return existing;
  } catch { /* première exécution */ }
  const secret = crypto.randomBytes(32).toString('hex');
  fs.writeFileSync(SECRET_FILE, secret, { mode: 0o600 });
  return secret;
}
const SECRET = loadSecret();

/* --------------------------------------------------------------- réponses */

export function send(res, status, body, headers = {}) {
  const buf = Buffer.isBuffer(body) ? body : Buffer.from(String(body ?? ''));
  res.writeHead(status, {
    'Content-Length': buf.length,
    'X-Content-Type-Options': 'nosniff',
    ...headers,
  });
  if (res.req.method === 'HEAD') res.end();
  else res.end(buf);
}

export function json(res, status, payload, headers = {}) {
  send(res, status, JSON.stringify(payload), {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    ...headers,
  });
}

/** Erreur métier renvoyée proprement au client. */
export class HttpError extends Error {
  constructor(status, message, details) {
    super(message);
    this.status = status;
    this.details = details;
  }
}
export const badRequest = (msg, details) => new HttpError(400, msg, details);
export const notFound = (msg = 'Ressource introuvable') => new HttpError(404, msg);

/* ------------------------------------------------------------ cookies/session */

export function parseCookies(req) {
  const out = {};
  const raw = req.headers.cookie;
  if (!raw) return out;
  for (const part of raw.split(';')) {
    const i = part.indexOf('=');
    if (i < 0) continue;
    out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}

export function setCookie(res, name, value, { maxAge = 60 * 60 * 24 * 120, path: p = '/', sameSite = 'Lax', httpOnly = true } = {}) {
  const bits = [`${name}=${encodeURIComponent(value)}`, `Path=${p}`, `Max-Age=${maxAge}`, `SameSite=${sameSite}`];
  if (httpOnly) bits.push('HttpOnly');
  const prev = res.getHeader('Set-Cookie');
  const all = prev ? (Array.isArray(prev) ? [...prev, bits.join('; ')] : [prev, bits.join('; ')]) : bits.join('; ');
  res.setHeader('Set-Cookie', all);
}

const sign = (value) => crypto.createHmac('sha256', SECRET).update(value).digest('base64url');

/** Comparaison à temps constant, tolérante aux longueurs différentes. */
function safeEqual(a, b) {
  const ha = crypto.createHash('sha256').update(String(a)).digest();
  const hb = crypto.createHash('sha256').update(String(b)).digest();
  return crypto.timingSafeEqual(ha, hb);
}

/** Session anonyme : identifiant de panier signé, pas de compte requis. */
export function session(req, res) {
  const raw = parseCookies(req).volt_session;
  if (raw) {
    const idx = raw.lastIndexOf('.');
    const id = raw.slice(0, idx);
    const mac = raw.slice(idx + 1);
    if (id && mac && safeEqual(mac, sign(id))) return id;
  }
  const id = crypto.randomUUID();
  setCookie(res, 'volt_session', `${id}.${sign(id)}`);
  return id;
}

/* ------------------------------------------------------------------- corps */

const MAX_BODY = 256 * 1024;

export async function readJson(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > MAX_BODY) throw new HttpError(413, 'Corps de requête trop volumineux');
    chunks.push(chunk);
  }
  if (!chunks.length) return {};
  const text = Buffer.concat(chunks).toString('utf8');
  try {
    const parsed = JSON.parse(text);
    if (parsed === null || typeof parsed !== 'object') throw new Error();
    return parsed;
  } catch {
    throw badRequest('JSON invalide');
  }
}

/* ----------------------------------------------------------------- routeur */

export class Router {
  #routes = [];
  add(method, pattern, handler) {
    const names = [];
    const regex = new RegExp(
      '^' + pattern
        .split('/')
        .map((seg) => {
          if (seg.startsWith(':')) { names.push(seg.slice(1)); return '([^/]+)'; }
          if (seg === '*') { names.push('wildcard'); return '(.*)'; }
          return seg.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        })
        .join('/') + '/?$',
    );
    this.#routes.push({ method, regex, names, handler });
    return this;
  }
  get(p, h) { return this.add('GET', p, h); }
  post(p, h) { return this.add('POST', p, h); }
  patch(p, h) { return this.add('PATCH', p, h); }
  put(p, h) { return this.add('PUT', p, h); }
  delete(p, h) { return this.add('DELETE', p, h); }

  match(method, pathname) {
    let pathExists = false;
    for (const route of this.#routes) {
      const m = route.regex.exec(pathname);
      if (!m) continue;
      pathExists = true;
      if (route.method !== method) continue;
      const params = {};
      route.names.forEach((n, i) => { params[n] = decodeURIComponent(m[i + 1]); });
      return { route, params };
    }
    return pathExists ? { methodNotAllowed: true } : null;
  }
}

/* ----------------------------------------------------------------- statique */

export async function serveStatic(req, res, pathname) {
  let rel = decodeURIComponent(pathname);
  if (rel.endsWith('/')) rel += 'index.html';
  const target = path.join(PUBLIC_DIR, path.normalize(rel));
  if (!target.startsWith(PUBLIC_DIR)) return false; // tentative de traversée

  let stat;
  try { stat = await fs.promises.stat(target); } catch { return false; }
  if (stat.isDirectory()) return false;

  const ext = path.extname(target).toLowerCase();
  const etag = `W/"${stat.size.toString(16)}-${stat.mtimeMs.toString(16)}"`;
  if (req.headers['if-none-match'] === etag) { res.writeHead(304).end(); return true; }

  res.writeHead(200, {
    'Content-Type': MIME[ext] || 'application/octet-stream',
    'Content-Length': stat.size,
    'ETag': etag,
    // `no-cache` = revalidation systématique : le navigateur ne resert jamais une
    // version périmée, mais un 304 évite le re-téléchargement. Pas besoin de
    // hachage de build, et une mise à jour est visible au premier rechargement.
    'Cache-Control': 'no-cache',
    'X-Content-Type-Options': 'nosniff',
  });
  if (req.method === 'HEAD') { res.end(); return true; }
  await new Promise((resolve, reject) => {
    const stream = fs.createReadStream(target);
    stream.on('error', reject);
    stream.on('close', resolve);
    stream.pipe(res);
  });
  return true;
}

/* ------------------------------------------------------------------ divers */

export const clamp = (n, min, max) => Math.min(max, Math.max(min, n));

export function slugify(text) {
  return text.normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
}

/** Générateur pseudo-aléatoire déterministe : seed stable d'une exécution à l'autre. */
export function mulberry32(seed) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
