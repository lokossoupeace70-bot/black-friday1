/**
 * routes.js — API REST de la boutique VOLT.
 * Toutes les routes renvoient du JSON ; les erreurs métier passent par HttpError.
 */
import crypto from 'node:crypto';
import { Router, json, badRequest, notFound, HttpError, clamp, session } from './core.js';
import { db, getProduct, hydrate, listCategories, parseColumn } from './db.js';
import { productArt } from './art.js';
import { EVENT, eventWindow, FREE_SHIPPING_CENTS, SHIPPING_CENTS, VAT_RATE, MAX_DISCOUNT } from './event.js';

const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'blackfriday2026';
const adminToken = crypto.createHmac('sha256', ADMIN_PASSWORD).update('volt-admin-v1').digest('hex');

export const api = new Router();

/* ============================================================== HELPERS === */

const productCard = (p) => ({
  id: p.id, slug: p.slug, name: p.name, brand: p.brand, category: p.category, hook: p.hook,
  price: p.price_cents, compare: p.compare_cents, discount: Math.round((1 - p.price_cents / p.compare_cents) * 100),
  stock: p.stock, rating: p.rating, reviewCount: p.review_count, soldToday: p.sold_today,
  featured: !!p.featured, badges: parseColumn(p.badges), image: `/media/${p.slug}.svg`,
});

function cartId(req, res) { return session(req, res); }

function readCart(cart) {
  const rows = db.prepare(`
    SELECT ci.id AS line_id, ci.qty AS line_qty, ci.variant AS line_variant,
           p.id AS product_id, p.slug, p.name, p.brand, p.category, p.price_cents, p.compare_cents, p.stock
    FROM cart_items ci
    JOIN products p ON p.id = ci.product_id
    WHERE ci.cart_id = ? ORDER BY ci.added_at`).all(cart);

  const deltaStmt = db.prepare('SELECT price_delta FROM variants WHERE product_id = ? AND value = ?');
  return rows.map((row) => {
    const delta = row.line_variant ? Number(deltaStmt.get(row.product_id, row.line_variant)?.price_delta ?? 0) : 0;
    const unit = row.price_cents + delta;
    return {
      id: row.line_id,
      productId: row.product_id,
      slug: row.slug,
      name: row.name,
      brand: row.brand,
      variant: row.line_variant,
      qty: row.line_qty,
      unit,
      compare: row.compare_cents,
      stock: row.stock,
      image: `/media/${row.slug}.svg`,
      lineTotal: unit * row.line_qty,
    };
  });
}

function computeTotals(items, promo) {
  const subtotal = items.reduce((sum, i) => sum + i.lineTotal, 0);
  const count = items.reduce((sum, i) => sum + i.qty, 0);
  let discount = 0;
  let freeShip = false;

  if (promo) {
    if (promo.kind === 'percent') discount = Math.round((subtotal * promo.value) / 100);
    else if (promo.kind === 'amount') discount = Math.min(promo.value, subtotal);
    else if (promo.kind === 'freeship') freeShip = true;
  }
  discount = Math.min(discount, subtotal);

  const net = subtotal - discount;
  let shipping = 0;
  if (count > 0) shipping = net >= FREE_SHIPPING_CENTS || freeShip ? 0 : SHIPPING_CENTS;

  const total = net + shipping;
  const tax = Math.round((total * VAT_RATE) / (1 + VAT_RATE));
  return {
    subtotal, discount, shipping, tax, total, count,
    shippingRemaining: Math.max(0, FREE_SHIPPING_CENTS - net),
    freeShippingReached: shipping === 0,
    freeShippingThreshold: FREE_SHIPPING_CENTS,
  };
}

function resolvePromo(code, subtotal = 0) {
  if (!code) return null;
  const promo = db.prepare('SELECT * FROM promos WHERE code = ? COLLATE NOCASE').get(String(code).trim());
  if (!promo || !promo.active) throw new HttpError(422, 'Ce code promo n’est pas valide.');
  if (promo.max_uses > 0 && promo.uses >= promo.max_uses) throw new HttpError(422, 'Ce code a atteint sa limite d’utilisation.');
  if (subtotal < promo.min_cents) {
    throw new HttpError(422, `Ce code s’active à partir de ${new Intl.NumberFormat('fr-FR').format(promo.min_cents)} F CFA d’achat.`);
  }
  return promo;
}

function slugFor(idOrSlug) {
  const product = getProduct(idOrSlug);
  if (!product) throw notFound('Produit introuvable.');
  return product;
}

/* ============================================================ BOUTIQUE ==== */

api.get('/api/health', (req, res) => json(res, 200, { ok: true, uptime: Math.round(process.uptime()) }));

api.get('/api/event', (req, res) => json(res, 200, {
  ...eventWindow(),
  maxDiscount: MAX_DISCOUNT,
  freeShippingThreshold: FREE_SHIPPING_CENTS,
  shippingCost: SHIPPING_CENTS,
  productCount: db.prepare('SELECT COUNT(*) AS n FROM products').get().n,
  categories: listCategories(),
}));

api.get('/api/products', (req, res, params, url) => {
  const q = url.searchParams;
  const where = [];
  const args = [];

  if (q.get('cat')) { where.push('category = ?'); args.push(q.get('cat')); }
  if (q.get('q')) {
    const term = `%${q.get('q').trim()}%`;
    where.push('(name LIKE ? OR brand LIKE ? OR hook LIKE ? OR category LIKE ?)');
    args.push(term, term, term, term);
  }
  if (q.get('min')) { where.push('price_cents >= ?'); args.push(Math.round(Number(q.get('min')) * 100)); }
  if (q.get('max')) { where.push('price_cents <= ?'); args.push(Math.round(Number(q.get('max')) * 100)); }
  if (q.get('deals') === '1') where.push('(1.0 - CAST(price_cents AS REAL)/compare_cents) >= 0.5');
  if (q.get('inStock') === '1') where.push('stock > 0');

  const sorts = {
    discount: '(1.0 - CAST(price_cents AS REAL)/compare_cents) DESC',
    price: 'price_cents ASC',
    '-price': 'price_cents DESC',
    rating: 'rating DESC, review_count DESC',
    popular: 'sold_today DESC',
    new: 'id DESC',
  };
  const order = sorts[q.get('sort')] || 'featured DESC, sold_today DESC';

  const limit = clamp(Number(q.get('limit')) || 48, 1, 60);
  const page = clamp(Number(q.get('page')) || 1, 1, 20);
  const clause = where.length ? `WHERE ${where.join(' AND ')}` : '';

  const rows = db.prepare(`SELECT * FROM products ${clause} ORDER BY ${order} LIMIT ? OFFSET ?`)
    .all(...args, limit, (page - 1) * limit);
  const { n: total } = db.prepare(`SELECT COUNT(*) AS n FROM products ${clause}`).get(...args);

  json(res, 200, { total, page, pages: Math.max(1, Math.ceil(total / limit)), items: rows.map(productCard) });
});

api.get('/api/products/:slug', (req, res, { slug }) => {
  const product = slugFor(slug);
  const relay = db.prepare(`
    SELECT * FROM products
    WHERE category = ? AND id <> ?
    ORDER BY ABS(price_cents - ?) ASC LIMIT 4`).all(product.category, product.id, product.price_cents);

  // Contrat d’API explicite en camelCase : le frontend ne dépend jamais du nom
  // des colonnes SQL, ce qui évite les divergences silencieuses (prix à 0, NaN…).
  json(res, 200, {
    ...productCard(product),
    description: product.description,
    specs: parseColumn(product.specs),
    variants: product.variants.map((v) => ({ group: v.group_name, value: v.value, delta: v.price_delta, stock: v.stock })),
    reviews: product.reviews,
    viewers: 12 + (product.id * 7) % 48,
    relay: relay.map(productCard),
  });
});

api.get('/api/categories', (req, res) => json(res, 200, { categories: listCategories() }));

/* Offre flash : renouvelée chaque jour à minuit, mise en avant en page d’accueil. */
api.get('/api/flash', (req, res) => {
  const { n } = db.prepare('SELECT COUNT(*) AS n FROM products').get();
  const dayIndex = Math.floor(Date.now() / 864e5);
  const offset = dayIndex % Math.max(1, n);
  const product = db.prepare('SELECT * FROM products ORDER BY id LIMIT 1 OFFSET ?').get(offset);
  const end = new Date();
  end.setHours(23, 59, 59, 999);
  json(res, 200, {
    product: productCard(product),
    code: 'FLASH10',
    extraPercent: 10,
    endsAt: end.toISOString(),
    claimedPercent: 60 + (dayIndex % 31),
  });
});

api.get('/api/social-proof', (req, res) => {
  const cutoff = new Date(Date.now() - 864e5).toISOString();
  const rows = db.prepare(`
    SELECT first_name AS name, city, created_at FROM orders
    WHERE created_at > ? ORDER BY id DESC LIMIT 5`).all(cutoff);
  const fallback = [
    ['Rachidatou', 'Cotonou'], ['Ulrich', 'Porto-Novo'], ['Sandra', 'Abomey-Calavi'], ['Marcelline', 'Parakou'], ['Rachid', 'Bohicon'],
  ].map(([name, city], i) => ({ name, city, created_at: new Date(Date.now() - i * 36e5).toISOString() }));
  json(res, 200, { recent: rows.length ? rows : fallback });
});

/* ================================================================= PANIER = */

api.get('/api/cart', (req, res) => {
  const id = cartId(req, res);
  const items = readCart(id);
  json(res, 200, { items, totals: computeTotals(items, null) });
});

api.post('/api/cart', async (req, res, params, url, body) => {
  const id = cartId(req, res);
  const product = slugFor(body.slug ?? body.productId);
  const qty = clamp(Number(body.qty) || 1, 1, 10);
  const variant = String(body.variant ?? product.variants[0]?.value ?? '');

  if (product.stock <= 0) throw new HttpError(409, 'Produit épuisé — il revient bientôt.');
  const existing = db.prepare('SELECT * FROM cart_items WHERE cart_id = ? AND product_id = ? AND variant = ?').get(id, product.id, variant);
  const desired = (existing?.qty ?? 0) + qty;
  if (desired > Math.min(10, product.stock)) {
    throw new HttpError(409, `Stock limité : ${product.stock} exemplaire(s) disponible(s).`);
  }

  if (existing) db.prepare('UPDATE cart_items SET qty = ? WHERE id = ?').run(desired, existing.id);
  else db.prepare('INSERT INTO cart_items (cart_id, product_id, variant, qty, added_at) VALUES (?,?,?,?,?)')
    .run(id, product.id, variant, qty, new Date().toISOString());

  db.prepare('INSERT INTO stats_events (kind, label, created_at) VALUES (?,?,?)').run('add_to_cart', product.slug, new Date().toISOString());
  const items = readCart(id);
  json(res, 201, { ok: true, added: { slug: product.slug, variant, qty }, items, totals: computeTotals(items) });
});

api.patch('/api/cart/:line', async (req, res, { line }, url, body) => {
  const id = cartId(req, res);
  const row = db.prepare('SELECT * FROM cart_items WHERE id = ? AND cart_id = ?').get(Number(line), id);
  if (!row) throw notFound('Ligne de panier introuvable.');
  const { stock } = db.prepare('SELECT stock FROM products WHERE id = ?').get(row.product_id);

  const qty = clamp(Number(body.qty ?? 0), 0, Math.min(10, Math.max(1, stock)));
  if (qty <= 0) db.prepare('DELETE FROM cart_items WHERE id = ?').run(row.id);
  else db.prepare('UPDATE cart_items SET qty = ? WHERE id = ?').run(qty, row.id);

  const items = readCart(id);
  json(res, 200, { items, totals: computeTotals(items) });
});

api.delete('/api/cart/:line', (req, res, { line }) => {
  const id = cartId(req, res);
  db.prepare('DELETE FROM cart_items WHERE id = ? AND cart_id = ?').run(Number(line), id);
  const items = readCart(id);
  json(res, 200, { items, totals: computeTotals(items) });
});

api.delete('/api/cart', (req, res) => {
  const id = cartId(req, res);
  db.prepare('DELETE FROM cart_items WHERE cart_id = ?').run(id);
  json(res, 200, { items: [], totals: computeTotals([]) });
});

api.post('/api/promo', async (req, res, params, url, body) => {
  const id = cartId(req, res);
  const items = readCart(id);
  const subtotal = items.reduce((s, i) => s + i.lineTotal, 0);
  const promo = resolvePromo(body.code, subtotal);
  const totals = computeTotals(items, promo);
  json(res, 200, {
    promo: { code: promo.code, label: promo.label, kind: promo.kind, value: promo.value },
    totals, items,
  });
});

/* ============================================================== COMMANDES = */

const ORDER_STATUSES = ['en préparation', 'expédiée', 'livrée', 'annulée'];

function newOrderNumber() {
  const alphabet = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
  let out = '';
  const bytes = crypto.randomBytes(6);
  for (const b of bytes) out += alphabet[b % alphabet.length];
  return `VOLT-${out}`;
}

api.post('/api/orders', async (req, res, params, url, body) => {
  const id = cartId(req, res);
  const items = readCart(id);
  if (!items.length) throw badRequest('Votre panier est vide.');

  const c = body.customer || {};
  const required = { email: 'adresse e-mail', firstName: 'prénom', lastName: 'nom', address: 'adresse', zip: 'code postal', city: 'ville' };
  const errors = {};
  for (const [key, label] of Object.entries(required)) {
    if (!String(c[key] ?? '').trim()) errors[key] = `Merci d’indiquer votre ${label}.`;
  }
  if (!errors.email && !/^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(String(c.email).trim())) errors.email = 'Adresse e-mail invalide.';
  // Bénin : boîtes postales (« BP 500 ») ou code numérique court.
  if (!errors.zip && !/^(bp\s?\d{1,6}|\d{4,6})$/i.test(String(c.zip).trim())) errors.zip = 'Code postal ou boîte postale invalide.';
  if (Object.keys(errors).length) throw new HttpError(422, 'Vérifiez les informations de livraison.', errors);

  let promo = null;
  if (body.promoCode) {
    const subtotal = items.reduce((s, i) => s + i.lineTotal, 0);
    promo = resolvePromo(body.promoCode, subtotal);
  }
  const totals = computeTotals(items, promo);

  const number = newOrderNumber();
  const now = new Date().toISOString();

  db.exec('BEGIN');
  try {
    for (const item of items) {
      const { stock } = db.prepare('SELECT stock FROM products WHERE id = ?').get(item.productId);
      if (stock < item.qty) throw new HttpError(409, `Stock insuffisant pour ${item.name}.`);
    }

    const info = db.prepare(`
      INSERT INTO orders (number, email, first_name, last_name, address, zip, city, country, phone, note,
        payment_method, subtotal_cents, discount_cents, shipping_cents, tax_cents, total_cents, promo_code, status, created_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`).run(
      number, String(c.email).trim().toLowerCase(), String(c.firstName).trim(), String(c.lastName).trim(),
      String(c.address).trim(), String(c.zip).trim(), String(c.city).trim(), String(c.country || 'Bénin').trim(),
      String(c.phone || '').trim(), String(c.note || '').slice(0, 400), String(body.paymentMethod || 'carte'),
      totals.subtotal, totals.discount, totals.shipping, totals.tax, totals.total, promo?.code ?? '', 'en préparation', now,
    );
    const orderId = Number(info.lastInsertRowid);

    const insertItem = db.prepare('INSERT INTO order_items (order_id, product_id, name, slug, variant, unit_cents, qty) VALUES (?,?,?,?,?,?,?)');
    const decStock = db.prepare('UPDATE products SET stock = MAX(0, stock - ?), sold_today = sold_today + ? WHERE id = ?');
    for (const item of items) {
      insertItem.run(orderId, item.productId, item.name, item.slug, item.variant, item.unit, item.qty);
      decStock.run(item.qty, item.qty, item.productId);
    }
    if (promo) db.prepare('UPDATE promos SET uses = uses + 1 WHERE code = ?').run(promo.code);
    db.prepare('DELETE FROM cart_items WHERE cart_id = ?').run(id);
    db.exec('COMMIT');

    json(res, 201, { ok: true, number, order: getOrder(number) });
  } catch (error) {
    db.exec('ROLLBACK');
    throw error;
  }
});

function getOrder(number, email) {
  const order = db.prepare('SELECT * FROM orders WHERE number = ? COLLATE NOCASE').get(String(number).trim());
  if (!order) return null;
  if (email && order.email !== String(email).trim().toLowerCase()) return null;
  order.items = db.prepare('SELECT name, slug, variant, unit_cents, qty FROM order_items WHERE order_id = ?').all(order.id);
  order.image = (slug) => `/media/${slug}.svg`;
  return order;
}

api.get('/api/orders/:number', (req, res, { number }, url) => {
  const email = url.searchParams.get('email');
  const order = getOrder(number, email);
  if (!order) throw notFound('Aucune commande ne correspond à ces informations.');

  const steps = ['en préparation', 'expédiée', 'livrée'];
  const idx = steps.indexOf(order.status);
  json(res, 200, {
    ...order,
    tracking: {
      steps: ['Commande confirmée', 'Préparation', 'Expédiée', 'Livrée'],
      current: order.status === 'annulée' ? -1 : idx + 1,
      cancelled: order.status === 'annulée',
      eta: new Date(new Date(order.created_at).getTime() + 2 * 864e5).toISOString(),
    },
  });
});

api.post('/api/newsletter', async (req, res, params, url, body) => {
  const email = String(body.email || '').trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(email)) throw new HttpError(422, 'Adresse e-mail invalide.');
  db.prepare('INSERT OR IGNORE INTO newsletter (email, created_at) VALUES (?,?)').run(email, new Date().toISOString());
  json(res, 201, { ok: true, message: 'Vous êtes inscrit : votre code de bienvenue part dans un instant.' });
});

/* ================================================================== ADMIN = */

function requireAdmin(req) {
  const token = req.headers['x-admin-token'];
  if (!token || token !== adminToken) throw new HttpError(401, 'Accès administrateur requis.');
}

api.post('/api/admin/login', async (req, res, params, url, body) => {
  if (String(body.password || '') !== ADMIN_PASSWORD) {
    await new Promise((r) => setTimeout(r, 400)); // freine le brute force
    throw new HttpError(401, 'Mot de passe incorrect.');
  }
  json(res, 200, { token: adminToken });
});

api.get('/api/admin/stats', (req, res) => {
  requireAdmin(req);
  const revenue = db.prepare('SELECT COALESCE(SUM(total_cents),0) AS v FROM orders WHERE status <> ?').get('annulée').v;
  const orders = db.prepare('SELECT COUNT(*) AS n FROM orders').get().n;
  const today = db.prepare("SELECT COALESCE(SUM(total_cents),0) AS v FROM orders WHERE date(created_at,'localtime') = date('now','localtime')").get().v;
  const items = db.prepare('SELECT COALESCE(SUM(qty),0) AS n FROM order_items').get().n;
  const visitors = db.prepare("SELECT COUNT(*) AS n FROM stats_events WHERE kind = 'add_to_cart'").get().n;

  json(res, 200, {
    revenue, orders, today, items, visitors,
    aov: orders ? Math.round(revenue / orders) : 0,
    conversion: visitors ? ((orders / visitors) * 100).toFixed(1) : '0.0',
    lowStock: db.prepare('SELECT id, slug, name, stock FROM products WHERE stock <= 15 ORDER BY stock ASC LIMIT 8').all(),
    topProducts: db.prepare(`
      SELECT oi.name, oi.slug, SUM(oi.qty) AS qty, SUM(oi.qty * oi.unit_cents) AS revenue
      FROM order_items oi GROUP BY oi.slug ORDER BY revenue DESC LIMIT 8`).all(),
    salesByDay: db.prepare(`
      SELECT date(created_at,'localtime') AS day, COUNT(*) AS orders, SUM(total_cents) AS revenue
      FROM orders GROUP BY day ORDER BY day DESC LIMIT 14`).all().reverse(),
    categories: db.prepare(`
      SELECT p.category, SUM(oi.qty) AS qty, SUM(oi.qty * oi.unit_cents) AS revenue
      FROM order_items oi JOIN products p ON p.id = oi.product_id
      GROUP BY p.category ORDER BY revenue DESC`).all(),
  });
});

api.get('/api/admin/orders', (req, res, params, url) => {
  requireAdmin(req);
  const status = url.searchParams.get('status');
  const q = `%${url.searchParams.get('q') || ''}%`;
  const rows = db.prepare(`
    SELECT id, number, email, first_name, last_name, city, total_cents, status, created_at, promo_code
    FROM orders
    WHERE (? = '' OR status = ?) AND (email LIKE ? OR number LIKE ? OR last_name LIKE ?)
    ORDER BY id DESC LIMIT 100`).all(status || '', status || '', q, q, q);
  json(res, 200, { orders: rows, statuses: ORDER_STATUSES });
});

api.patch('/api/admin/orders/:id', async (req, res, { id }, url, body) => {
  requireAdmin(req);
  if (!ORDER_STATUSES.includes(body.status)) throw badRequest('Statut inconnu.');
  const info = db.prepare('UPDATE orders SET status = ? WHERE id = ?').run(body.status, Number(id));
  if (!info.changes) throw notFound('Commande introuvable.');
  json(res, 200, { ok: true });
});

api.get('/api/admin/products', (req, res, params, url) => {
  requireAdmin(req);
  const q = `%${url.searchParams.get('q') || ''}%`;
  json(res, 200, {
    products: db.prepare('SELECT id, slug, name, brand, category, price_cents, compare_cents, stock, featured FROM products WHERE name LIKE ? OR brand LIKE ? ORDER BY id LIMIT 200').all(q, q),
  });
});

api.patch('/api/admin/products/:id', async (req, res, { id }, url, body) => {
  requireAdmin(req);
  const fields = [];
  const args = [];
  if (body.price !== undefined) { fields.push('price_cents = ?'); args.push(Math.round(Number(body.price))); }
  if (body.stock !== undefined) { fields.push('stock = ?'); args.push(clamp(Math.round(Number(body.stock)), 0, 9999)); }
  if (body.featured !== undefined) { fields.push('featured = ?'); args.push(body.featured ? 1 : 0); }
  if (!fields.length) throw badRequest('Aucun champ à mettre à jour.');
  db.prepare(`UPDATE products SET ${fields.join(', ')} WHERE id = ?`).run(...args, Number(id));
  json(res, 200, { ok: true });
});

api.get('/api/admin/promos', (req, res) => {
  requireAdmin(req);
  json(res, 200, { promos: db.prepare('SELECT * FROM promos ORDER BY code').all() });
});

api.post('/api/admin/promos', async (req, res, params, url, body) => {
  requireAdmin(req);
  const code = String(body.code || '').trim().toUpperCase();
  if (!/^[A-Z0-9]{3,20}$/.test(code)) throw badRequest('Code invalide (3 à 20 caractères A-Z, 0-9).');
  if (!['percent', 'amount', 'freeship'].includes(body.kind)) throw badRequest('Type de remise inconnu.');
  db.prepare('INSERT OR REPLACE INTO promos (code, label, kind, value, min_cents, max_uses, uses, active) VALUES (?,?,?,?,?,?,COALESCE((SELECT uses FROM promos WHERE code = ?),0),1)')
    .run(code, String(body.label || code), body.kind, Math.round(Number(body.value) || 0), Math.round(Number(body.min || 0) * 100), Math.round(Number(body.maxUses) || 0), code);
  json(res, 201, { ok: true, code });
});

api.delete('/api/admin/promos/:code', (req, res, { code }) => {
  requireAdmin(req);
  db.prepare('DELETE FROM promos WHERE code = ?').run(String(code).toUpperCase());
  json(res, 200, { ok: true });
});

/* ================================================================ MÉDIAS == */

api.get('/media/:file', (req, res, { file }, url) => {
  const slug = file.replace(/\.svg$/i, '');
  const product = db.prepare('SELECT slug, name, brand, category FROM products WHERE slug = ?').get(slug);
  if (!product) throw notFound('Visuel introuvable.');
  // `?v=<coloris>` : le visuel se recompose selon la finition choisie.
  const variant = url.searchParams.get('v') || '';
  const svg = productArt({ ...product, variant });
  const etag = `"${Buffer.byteLength(svg).toString(16)}-${variant.length.toString(16)}"`;
  if (req.headers['if-none-match'] === etag) { res.writeHead(304).end(); return; }
  res.writeHead(200, {
    'Content-Type': 'image/svg+xml; charset=utf-8',
    'Cache-Control': 'no-cache',
    'ETag': etag,
    'Content-Length': Buffer.byteLength(svg),
  });
  res.end(svg);
});

/* Message d’aide : évite une 404 muette pendant l’intégration. */
api.add('GET', '/api', (req, res) => json(res, 200, {
  name: 'VOLT Black Friday API',
  version: '1.0.0',
  routes: [
    'GET /api/event', 'GET /api/products', 'GET /api/products/:slug', 'GET /api/categories',
    'GET /api/flash', 'GET /api/social-proof', 'GET /api/cart', 'POST /api/cart',
    'PATCH /api/cart/:line', 'DELETE /api/cart/:line', 'POST /api/promo',
    'POST /api/orders', 'GET /api/orders/:number?email=', 'POST /api/newsletter',
    'POST /api/admin/login', 'GET /api/admin/stats', 'GET /api/admin/orders',
    'PATCH /api/admin/orders/:id', 'GET /api/admin/products', 'PATCH /api/admin/products/:id',
    'GET /api/admin/promos', 'POST /api/admin/promos', 'DELETE /api/admin/promos/:code',
  ],
}));

export { EVENT };
