/**
 * event.js — configuration de la campagne Black Friday.
 * Une seule source de vérité pour les dates, partagée par le serveur et l'API.
 */
const TZ_OFFSET = '+01:00';

export const EVENT = {
  name: 'BLACK FRIDAY',
  claim: 'Le drop tech de l’année',
  /** Ouverture de l’accès anticipé. */
  startsAt: new Date('2026-11-23T09:00:00' + TZ_OFFSET),
  /** Vendredi noir : pic de l’événement. */
  peakAt: new Date('2026-11-27T00:00:00' + TZ_OFFSET),
  /** Clôture définitive des offres. */
  endsAt: new Date('2026-11-30T23:59:59' + TZ_OFFSET),
};

/** Réduction maximale affichée dans les bandeaux marketing. */
export const MAX_DISCOUNT = 70;

/**
 * Prix et seuils en FCFA (XOF, pas de sous-unité décimale) : les colonnes
 * `*_cents` conservent leur nom d'origine mais contiennent désormais des francs CFA entiers.
 */
export const FREE_SHIPPING_CENTS = 50000;

/** Frais de port standard, grande couronne de Cotonou (FCFA). */
export const SHIPPING_CENTS = 2500;

/** TVA béninoise 18 %, prix affichés TTC. */
export const VAT_RATE = 0.18;

export function eventWindow(now = new Date()) {
  const msLeft = EVENT.endsAt.getTime() - now.getTime();
  return {
    name: EVENT.name,
    claim: EVENT.claim,
    startsAt: EVENT.startsAt.toISOString(),
    peakAt: EVENT.peakAt.toISOString(),
    endsAt: EVENT.endsAt.toISOString(),
    msLeft: Math.max(0, msLeft),
    isLive: msLeft > 0,
    phase: now < EVENT.startsAt ? 'prévente' : now < EVENT.peakAt ? 'accès anticipé' : msLeft > 0 ? 'black friday' : 'terminé',
  };
}
